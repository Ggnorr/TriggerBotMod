package com.example.happyclient;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SwordItem;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import org.lwjgl.glfw.GLFW;

import java.util.Random;

public class HappyClient implements ClientModInitializer {
    private static final MinecraftClient client = MinecraftClient.getInstance();
    private static boolean enabled = false;
    private static KeyBinding toggleKey;
    private static boolean wasOnTarget = false;
    private static long postEatDelayUntil = 0L; // ms

    // Cooldown logic
    private static final Random RANDOM = new Random();
    private static float nextGroundCooldownThreshold = 0.0f;
    private static int lastGroundCooldownGroup = -1;

    // Jump/descent logic
    private static boolean jumping = false;
    private static boolean inDescent = false;
    private static float nextAirCooldownThreshold = 0.0f;
    private static boolean lastWasDescentAttack = false;

    @Override
    public void onInitializeClient() {
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.triggerbotlegit.toggle",
                GLFW.GLFW_KEY_LEFT_ALT,
                "category.triggerbotlegit"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            // Toggle key logic
            while (toggleKey.wasPressed()) {
                enabled = !enabled;
                if (client.player != null) {
                    client.player.sendMessage(
                            net.minecraft.text.Text.of("TriggerBot: " + (enabled ? "ON" : "OFF")), true
                    );
                }
            }

            if (!enabled || client.player == null || client.crosshairTarget == null) {
                wasOnTarget = false;
                jumping = false;
                inDescent = false;
                lastWasDescentAttack = false;
                return;
            }

            // Only if holding a sword
            ItemStack mainHand = client.player.getMainHandStack();
            if (!(mainHand.getItem() instanceof SwordItem)) {
                wasOnTarget = false;
                jumping = false;
                inDescent = false;
                lastWasDescentAttack = false;
                return;
            }

            // Only attack players
            boolean onTarget = false;
            if (client.crosshairTarget.getType() == HitResult.Type.ENTITY) {
                Entity target = ((EntityHitResult) client.crosshairTarget).getEntity();
                if (target instanceof PlayerEntity && target != client.player) {
                    onTarget = true;
                }
            }

            // Don't attack while eating from offhand
            ItemStack offhand = client.player.getStackInHand(Hand.OFF_HAND);
            boolean isEating = client.player.isUsingItem() &&
                    client.player.getActiveHand() == Hand.OFF_HAND &&
                    offhand.isFood();
            if (isEating) {
                wasOnTarget = false;
                jumping = false;
                inDescent = false;
                lastWasDescentAttack = false;
                return;
            }

            // Wait post-eating delay before attacking again (no delay logic anymore)
            if (System.currentTimeMillis() < postEatDelayUntil) {
                wasOnTarget = false;
                jumping = false;
                inDescent = false;
                lastWasDescentAttack = false;
                return;
            }

            boolean onGround = client.player.isOnGround();
            double playerVelY = client.player.getVelocity().y;

            // JUMP LOGIC
            // Early jump phase: if ascending, do NOT allow ground hits
            // Detect start of descent as soon as possible (playerVelY < -0.01)
            // When in descent, allow air attack if cooldown threshold (randomized 93-100%) is reached, never skip attack as long as it's 93% or above

            if (!onGround) {
                // If we're moving upwards, we're in the jump phase (cancel ground hits)
                if (playerVelY > 0.01) {
                    jumping = true;
                    inDescent = false;
                    lastWasDescentAttack = false;
                    wasOnTarget = onTarget;
                    return;
                }

                // Detect start of descent as soon as possible
                if (playerVelY < -0.01) {
                    inDescent = true;
                    jumping = false;
                }

                // Descent phase (including apex and down)
                if (inDescent && onTarget) {
                    if (nextAirCooldownThreshold == 0.0f) {
                        // Pick a new air threshold for this descent (93-100%)
                        nextAirCooldownThreshold = randomCooldownBetween(0.93f, 1.00f);
                    }
                    float attackCooldown = client.player.getAttackCooldownProgress(0.0f);
                    // As soon as we reach or pass the threshold, attack IMMEDIATELY and never skip as long as >= 93%
                    if (attackCooldown >= nextAirCooldownThreshold) {
                        doAttackVanilla();
                        lastWasDescentAttack = true;
                        // After attack, for smart multi-descent attacks, pick a new threshold if cooldown still >= 93%
                        if (attackCooldown >= 0.93f) {
                            nextAirCooldownThreshold = randomCooldownBetween(0.93f, 1.00f);
                        } else {
                            // Reset threshold, wait for next 93%+
                            nextAirCooldownThreshold = 0.0f;
                        }
                    }
                } else {
                    lastWasDescentAttack = false;
                    nextAirCooldownThreshold = 0.0f;
                }
                wasOnTarget = onTarget;
                return;
            } else {
                // On ground, reset jump/descent state
                jumping = false;
                inDescent = false;
                lastWasDescentAttack = false;
                nextAirCooldownThreshold = 0.0f;
            }

            // GROUND LOGIC
            if (onGround && onTarget) {
                // Pick a new cooldown group and threshold when switching from off to on target, or after an attack
                if (!wasOnTarget || nextGroundCooldownThreshold == 0.0f) {
                    int groupRoll = RANDOM.nextInt(100);
                    if (groupRoll < 60) {
                        // 60%: 94-100%
                        lastGroundCooldownGroup = 0;
                        nextGroundCooldownThreshold = randomCooldownBetween(0.94f, 1.00f);
                    } else if (groupRoll < 95) {
                        // 35%: 85-94%
                        lastGroundCooldownGroup = 1;
                        nextGroundCooldownThreshold = randomCooldownBetween(0.85f, 0.94f);
                    } else {
                        // 5%: 75-85%
                        lastGroundCooldownGroup = 2;
                        nextGroundCooldownThreshold = randomCooldownBetween(0.75f, 0.85f);
                    }
                }

                float attackCooldown = client.player.getAttackCooldownProgress(0.0f);
                if (attackCooldown >= nextGroundCooldownThreshold) {
                    doAttackVanilla();
                    // After attack, pick a new cooldown group and threshold for next attack
                    int groupRoll = RANDOM.nextInt(100);
                    if (groupRoll < 60) {
                        lastGroundCooldownGroup = 0;
                        nextGroundCooldownThreshold = randomCooldownBetween(0.94f, 1.00f);
                    } else if (groupRoll < 95) {
                        lastGroundCooldownGroup = 1;
                        nextGroundCooldownThreshold = randomCooldownBetween(0.85f, 0.94f);
                    } else {
                        lastGroundCooldownGroup = 2;
                        nextGroundCooldownThreshold = randomCooldownBetween(0.75f, 0.85f);
                    }
                }
            } else {
                // Reset when no longer on target or not on ground
                nextGroundCooldownThreshold = 0.0f;
                lastGroundCooldownGroup = -1;
            }

            wasOnTarget = onTarget;
        });
    }

    // Randomized cooldown between min and max, log-normal for human-likeness
    private static float randomCooldownBetween(float min, float max) {
        // Log-normal distribution, clamped to [min, max]
        double mean = Math.log((min + max) / 2.0);
        double stddev = 0.1 + RANDOM.nextDouble() * 0.06; // subtle variation
        float val;
        do {
            val = (float) Math.exp(mean + stddev * RANDOM.nextGaussian());
        } while (val < min || val > max);
        // Add a tiny random jitter for added realism
        val += (RANDOM.nextFloat() - 0.5f) * 0.005f;
        if (val < min) val = min;
        if (val > max) val = max;
        return val;
    }

    private static void doAttackVanilla() {
        if (client != null && client.player != null) {
            client.doAttack();
        }
    }
}