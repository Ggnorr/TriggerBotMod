package com.example.happyclient;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SwordItem;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.entity.damage.DamageSource;
import org.lwjgl.glfw.GLFW;

import java.util.Random;

public class HappyClient implements ClientModInitializer {
    private static final MinecraftClient client = MinecraftClient.getInstance();
    private static boolean enabled = false;
    private static KeyBinding toggleKey;
    private static boolean wasOnTarget = false;
    private static long postEatDelayUntil = 0L; // ms

    // Cooldown logic
    private static final Random RANDOM = new Random();
    private static float nextGroundCooldownThreshold = 0.0f;
    private static int groundCooldownMode = 0; // 0=90-96, 1=96-100, 2=85-92, 3=635-660ms
    private static long groundAbsoluteEarliestAttack = 0L;

    // Jump/descent logic
    private static boolean jumping = false;
    private static boolean inDescent = false;
    private static float nextAirCooldownThreshold = 0.0f;
    private static boolean lastWasDescentAttack = false;

    // Crit punish logic
    private static boolean enemyCritting = false;
    private static long lastEnemyCritTime = 0L;
    private static final long ENEMY_CRIT_GRACE_MS = 1000L; // 1 second

    @Override
    public void onInitializeClient() {
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.triggerbotlegit.toggle",
                GLFW.GLFW_KEY_LEFT_ALT,
                "category.triggerbotlegit"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            // Toggle key logic
            while (toggleKey.wasPressed()) {
                enabled = !enabled;
                if (client.player != null) {
                    client.player.sendMessage(
                            net.minecraft.text.Text.of("TriggerBot: " + (enabled ? "ON" : "OFF")), true
                    );
                }
            }

            // Handle crit punish cooldown window expiration
            if (enemyCritting && System.currentTimeMillis() - lastEnemyCritTime > ENEMY_CRIT_GRACE_MS) {
                enemyCritting = false;
            }

            if (!enabled || client.player == null || client.crosshairTarget == null) {
                wasOnTarget = false;
                jumping = false;
                inDescent = false;
                lastWasDescentAttack = false;
                nextGroundCooldownThreshold = 0.0f;
                groundCooldownMode = 0;
                groundAbsoluteEarliestAttack = 0L;
                return;
            }

            // Only if holding a sword
            ItemStack mainHand = client.player.getMainHandStack();
            if (!(mainHand.getItem() instanceof SwordItem)) {
                wasOnTarget = false;
                jumping = false;
                inDescent = false;
                lastWasDescentAttack = false;
                nextGroundCooldownThreshold = 0.0f;
                groundCooldownMode = 0;
                groundAbsoluteEarliestAttack = 0L;
                return;
            }

            // Only attack players
            boolean onTarget = false;
            boolean targetIsEating = false;
            Entity target = null;
            if (client.crosshairTarget.getType() == HitResult.Type.ENTITY) {
                target = ((EntityHitResult) client.crosshairTarget).getEntity();
                if (target instanceof PlayerEntity && target != client.player) {
                    onTarget = true;
                    PlayerEntity targetPlayer = (PlayerEntity) target;
                    ItemStack targetMain = targetPlayer.getMainHandStack();
                    ItemStack targetOff = targetPlayer.getOffHandStack();
                    boolean mainEating = targetPlayer.isUsingItem() && targetPlayer.getActiveHand() == Hand.MAIN_HAND && targetMain.isFood();
                    boolean offEating = targetPlayer.isUsingItem() && targetPlayer.getActiveHand() == Hand.OFF_HAND && targetOff.isFood();
                    targetIsEating = mainEating || offEating;
                }
            }

            // Don't attack while eating from offhand
            ItemStack offhand = client.player.getStackInHand(Hand.OFF_HAND);
            boolean isEating = client.player.isUsingItem() &&
                    client.player.getActiveHand() == Hand.OFF_HAND &&
                    offhand.isFood();
            if (isEating) {
                wasOnTarget = false;
                jumping = false;
                inDescent = false;
                lastWasDescentAttack = false;
                nextGroundCooldownThreshold = 0.0f;
                groundCooldownMode = 0;
                groundAbsoluteEarliestAttack = 0L;
                return;
            }

            // Wait post-eating delay before attacking again (no delay logic anymore)
            if (System.currentTimeMillis() < postEatDelayUntil) {
                wasOnTarget = false;
                jumping = false;
                inDescent = false;
                lastWasDescentAttack = false;
                nextGroundCooldownThreshold = 0.0f;
                groundCooldownMode = 0;
                groundAbsoluteEarliestAttack = 0L;
                return;
            }

            boolean onGround = client.player.isOnGround();
            double playerVelY = client.player.getVelocity().y;

            // JUMP LOGIC (unchanged, but using humanized delay)
            if (!onGround) {
                if (playerVelY > 0.01) {
                    jumping = true;
                    inDescent = false;
                    lastWasDescentAttack = false;
                    wasOnTarget = onTarget;
                    return;
                }
                if (playerVelY < -0.01) {
                    inDescent = true;
                    jumping = false;
                }
                if (inDescent && onTarget) {
                    if (nextAirCooldownThreshold == 0.0f) {
                        if (targetIsEating) {
                            nextAirCooldownThreshold = humanRandomizedCooldown(0.95f, 1.00f);
                        } else {
                            nextAirCooldownThreshold = humanRandomizedCooldown(0.85f, 0.95f);
                        }
                    }
                    float attackCooldown = client.player.getAttackCooldownProgress(0.0f);
                    if (attackCooldown >= nextAirCooldownThreshold) {
                        doAttackVanilla();
                        lastWasDescentAttack = true;
                        if (attackCooldown >= nextAirCooldownThreshold) {
                            if (targetIsEating) {
                                nextAirCooldownThreshold = humanRandomizedCooldown(0.95f, 1.00f);
                            } else {
                                nextAirCooldownThreshold = humanRandomizedCooldown(0.85f, 0.95f);
                            }
                        } else {
                            nextAirCooldownThreshold = 0.0f;
                        }
                    }
                } else {
                    lastWasDescentAttack = false;
                    nextAirCooldownThreshold = 0.0f;
                }
                wasOnTarget = onTarget;
                return;
            } else {
                jumping = false;
                inDescent = false;
                lastWasDescentAttack = false;
                nextAirCooldownThreshold = 0.0f;
            }

            // GROUND LOGIC
            if (onGround && onTarget) {
                if (enemyCritting) {
                    // Crit punish: 96-100% cooldown, log-normal as requested
                    if (nextGroundCooldownThreshold == 0.0f) {
                        nextGroundCooldownThreshold = humanRandomizedCooldown(0.96f, 1.00f);
                    }
                    float attackCooldown = client.player.getAttackCooldownProgress(0.0f);
                    if (attackCooldown >= nextGroundCooldownThreshold) {
                        doAttackVanilla();
                        nextGroundCooldownThreshold = humanRandomizedCooldown(0.96f, 1.00f);
                    }
                } else {
                    if (!wasOnTarget || (nextGroundCooldownThreshold == 0.0f && groundAbsoluteEarliestAttack == 0L)) {
                        int roll = RANDOM.nextInt(100);
                        if (roll < 70) {
                            // 70%: 90-96% cooldown
                            groundCooldownMode = 0;
                            nextGroundCooldownThreshold = humanRandomizedCooldown(0.90f, 0.96f);
                            groundAbsoluteEarliestAttack = 0L;
                        } else if (roll < 80) {
                            // 10%: 96-100% cooldown
                            groundCooldownMode = 1;
                            nextGroundCooldownThreshold = humanRandomizedCooldown(0.96f, 1.00f);
                            groundAbsoluteEarliestAttack = 0L;
                        } else if (roll < 90) {
                            // 10%: 85-92% cooldown
                            groundCooldownMode = 2;
                            nextGroundCooldownThreshold = humanRandomizedCooldown(0.85f, 0.92f);
                            groundAbsoluteEarliestAttack = 0L;
                        } else {
                            // 10%: 635-660ms absolute delay
                            groundCooldownMode = 3;
                            nextGroundCooldownThreshold = 0.0f;
                            groundAbsoluteEarliestAttack = System.currentTimeMillis() + (635 + RANDOM.nextInt(26));
                        }
                    }

                    float attackCooldown = client.player.getAttackCooldownProgress(0.0f);

                    if (groundCooldownMode == 3) {
                        // Absolute delay mode
                        if (System.currentTimeMillis() >= groundAbsoluteEarliestAttack) {
                            doAttackVanilla();
                            nextGroundCooldownThreshold = 0.0f;
                            groundCooldownMode = 0;
                            groundAbsoluteEarliestAttack = 0L;
                        }
                    } else {
                        // Percentage threshold mode
                        if (attackCooldown >= nextGroundCooldownThreshold) {
                            doAttackVanilla();
                            // After attack, pick a new mode/threshold for the next attack
                            int roll = RANDOM.nextInt(100);
                            if (roll < 70) {
                                groundCooldownMode = 0;
                                nextGroundCooldownThreshold = humanRandomizedCooldown(0.90f, 0.96f);
                                groundAbsoluteEarliestAttack = 0L;
                            } else if (roll < 80) {
                                groundCooldownMode = 1;
                                nextGroundCooldownThreshold = humanRandomizedCooldown(0.96f, 1.00f);
                                groundAbsoluteEarliestAttack = 0L;
                            } else if (roll < 90) {
                                groundCooldownMode = 2;
                                nextGroundCooldownThreshold = humanRandomizedCooldown(0.85f, 0.92f);
                                groundAbsoluteEarliestAttack = 0L;
                            } else {
                                groundCooldownMode = 3;
                                nextGroundCooldownThreshold = 0.0f;
                                groundAbsoluteEarliestAttack = System.currentTimeMillis() + (635 + RANDOM.nextInt(26));
                            }
                        }
                    }
                }
            } else {
                nextGroundCooldownThreshold = 0.0f;
                groundCooldownMode = 0;
                groundAbsoluteEarliestAttack = 0L;
            }

            wasOnTarget = onTarget;
        });
    }

    // Called from the mixin when the player takes melee damage from another player
    public static void onSelfDamaged(DamageSource source) {
        // Only interested in melee damage from another player
        Entity attacker = source.getAttacker();
        if (attacker instanceof PlayerEntity) {
            // Further restrict to melee only (not projectile/magic/environment)
            if (!source.isProjectile() && !source.isExplosive() && !source.isMagic() && !source.isFire() && !source.isBypassInvul()) {
                enemyCritting = true;
                lastEnemyCritTime = System.currentTimeMillis();
            }
        }
    }

    // Human-like randomized cooldown between min and max (log-normal + jitter)
    private static float humanRandomizedCooldown(float min, float max) {
        double mean = Math.log((min + max) / 2.0);
        double stddev = 0.13 + RANDOM.nextDouble() * 0.08; // more human
        float val;
        do {
            val = (float) Math.exp(mean + stddev * RANDOM.nextGaussian());
        } while (val < min || val > max);
        // Add a tiny random jitter for added realism
        val += (RANDOM.nextFloat() - 0.5f) * 0.006f;
        if (val < min) val = min;
        if (val > max) val = max;
        return val;
    }

    private static void doAttackVanilla() {
        if (client != null && client.player != null) {
            client.doAttack();
        }
    }
}