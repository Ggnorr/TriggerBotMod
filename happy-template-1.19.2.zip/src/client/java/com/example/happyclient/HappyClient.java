package com.example.happyclient;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SwordItem;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import org.lwjgl.glfw.GLFW;
import java.util.Random;

public class HappyClient implements ClientModInitializer {
    private static final MinecraftClient client = MinecraftClient.getInstance();
    private static boolean enabled = false;
    private static KeyBinding toggleKey;
    private static boolean wasOnTarget = false;
    private static long postEatDelayUntil = 0L; // ms
    private static final Random RANDOM = new Random();

    // Ground delays
    private static long nextGroundAttackAllowedAt = 0L;
    private static final int GROUND_DELAY_COMBO_MIN = 570;
    private static final int GROUND_DELAY_COMBO_MAX = 590;
    private static final int GROUND_DELAY_COMBO_SHORT_MIN = 550;
    private static final int GROUND_DELAY_COMBO_SHORT_MAX = 570;
    private static final int GROUND_DELAY_ATTACKING_MIN = 600;
    private static final int GROUND_DELAY_ATTACKING_MAX = 627;

    private static final int POST_EAT_DELAY_MIN = 65;
    private static final int POST_EAT_DELAY_MAX = 70;

    private static final int FIRST_ATTACK_REACTION_MIN = 36;
    private static final int FIRST_ATTACK_REACTION_MAX = 55;

    // Jump/descent delays
    private static long nextAirAttackAllowedAt = 0L;
    private static boolean lastWasDescentAttack = false;

    // Memory for autocorrelation for each delay type
    private static long lastGroundComboDelay = -1L;
    private static long lastGroundShortComboDelay = -1L;
    private static long lastGroundAttackingDelay = -1L;
    private static long lastPostEatDelay = -1L;
    private static long lastFirstAttackDelay = -1L;
    private static long lastAirDescentExtraDelay = -1L;
    private static long lastAirDescentMinimalDelay = -1L;

    // For first attack logic
    private static boolean waitingFirstAttack = false;
    private static long firstAttackScheduledFor = 0L;

    @Override
    public void onInitializeClient() {
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.triggerbotlegit.toggle",
                GLFW.GLFW_KEY_LEFT_ALT,
                "category.triggerbotlegit"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            // Toggle key logic
            while (toggleKey.wasPressed()) {
                enabled = !enabled;
                if (client.player != null) {
                    client.player.sendMessage(
                        net.minecraft.text.Text.of("TriggerBot: " + (enabled ? "ON" : "OFF")), true
                    );
                }
            }

            if (!enabled || client.player == null || client.crosshairTarget == null) {
                wasOnTarget = false;
                lastWasDescentAttack = false;
                waitingFirstAttack = false;
                return;
            }

            // Only if holding a sword
            ItemStack mainHand = client.player.getMainHandStack();
            if (!(mainHand.getItem() instanceof SwordItem)) {
                wasOnTarget = false;
                lastWasDescentAttack = false;
                waitingFirstAttack = false;
                return;
            }

            // Only attack players
            boolean onTarget = false;
            PlayerEntity targetPlayer = null;
            if (client.crosshairTarget.getType() == HitResult.Type.ENTITY) {
                Entity target = ((EntityHitResult) client.crosshairTarget).getEntity();
                if (target instanceof PlayerEntity && target != client.player) {
                    onTarget = true;
                    targetPlayer = (PlayerEntity) target;
                }
            }

            // Don't attack while eating from offhand
            ItemStack offhand = client.player.getStackInHand(Hand.OFF_HAND);
            boolean isEating = client.player.isUsingItem() &&
                               client.player.getActiveHand() == Hand.OFF_HAND &&
                               offhand.isFood();
            if (isEating) {
                postEatDelayUntil = System.currentTimeMillis() + humanizedDelay(POST_EAT_DELAY_MIN, POST_EAT_DELAY_MAX, DelayType.POST_EAT);
                wasOnTarget = false;
                lastWasDescentAttack = false;
                waitingFirstAttack = false;
                return;
            }

            // Wait post-eating delay before attacking again
            if (System.currentTimeMillis() < postEatDelayUntil) {
                wasOnTarget = false;
                lastWasDescentAttack = false;
                waitingFirstAttack = false;
                return;
            }

            boolean onGround = client.player.isOnGround();
            double playerVelY = client.player.getVelocity().y;
            long now = System.currentTimeMillis();

            if (onGround) {
                lastWasDescentAttack = false;

                if (playerVelY > 0.08) { // Ascending
                    wasOnTarget = false;
                    waitingFirstAttack = false;
                    return;
                }

                // FIRST ATTACK HUMANIZED REACTION TIME
                if (onTarget && !wasOnTarget && now >= nextGroundAttackAllowedAt) {
                    if (!waitingFirstAttack) {
                        // Schedule the first attack with a humanized delay
                        long firstDelay = humanizedDelay(FIRST_ATTACK_REACTION_MIN, FIRST_ATTACK_REACTION_MAX, DelayType.FIRST_ATTACK);
                        firstAttackScheduledFor = now + firstDelay;
                        waitingFirstAttack = true;
                        // Don't attack yet, wait until scheduled
                        wasOnTarget = onTarget;
                        return;
                    } else if (waitingFirstAttack && now < firstAttackScheduledFor) {
                        // Still waiting for first attack delay
                        wasOnTarget = onTarget;
                        return;
                    } else if (waitingFirstAttack && now >= firstAttackScheduledFor) {
                        // Time to attack
                        if (targetPlayer != null) {
                            long delay;
                            if (isTargetAttacking(targetPlayer)) {
                                delay = humanizedDelay(GROUND_DELAY_ATTACKING_MIN, GROUND_DELAY_ATTACKING_MAX, DelayType.GROUND_ATTACKING);
                            } else if (isGettingComboedOrEatingOrLookingAway(targetPlayer)) {
                                int chance = RANDOM.nextInt(100);
                                if (chance < 95) {
                                    delay = humanizedDelay(GROUND_DELAY_COMBO_MIN, GROUND_DELAY_COMBO_MAX, DelayType.GROUND_COMBO);
                                } else {
                                    delay = humanizedDelay(GROUND_DELAY_COMBO_SHORT_MIN, GROUND_DELAY_COMBO_SHORT_MAX, DelayType.GROUND_COMBO_SHORT);
                                }
                            } else {
                                delay = humanizedDelay(GROUND_DELAY_COMBO_MIN, GROUND_DELAY_COMBO_MAX, DelayType.GROUND_COMBO);
                            }
                            doAttackVanilla();
                            nextGroundAttackAllowedAt = now + delay;
                        } else {
                            doAttackVanilla();
                            nextGroundAttackAllowedAt = now + humanizedDelay(GROUND_DELAY_COMBO_MIN, GROUND_DELAY_COMBO_MAX, DelayType.GROUND_COMBO);
                        }
                        waitingFirstAttack = false;
                    }
                } else {
                    waitingFirstAttack = false;
                }
                wasOnTarget = onTarget;
            } else {
                waitingFirstAttack = false;
                // In air (jump/descent)
                if (playerVelY < -0.08) { // Descent phase
                    if (onTarget && !lastWasDescentAttack) {
                        long extraDelay = 0;
                        if (targetPlayer != null && shouldApplyExtraDelay(targetPlayer)) {
                            extraDelay = humanizedDelay(80, 100, DelayType.AIR_DESCENT_EXTRA);
                        } else {
                            extraDelay = humanizedDelay(15, 50, DelayType.AIR_DESCENT_MINIMAL);
                        }
                        nextAirAttackAllowedAt = now + extraDelay;
                        lastWasDescentAttack = true;
                    }
                    // Attack only after the random delay, and only once per descent
                    if (lastWasDescentAttack && now >= nextAirAttackAllowedAt && onTarget) {
                        doAttackVanilla();
                    }
                } else {
                    lastWasDescentAttack = false;
                }
                wasOnTarget = onTarget;
            }
        });
    }

    private static boolean isTargetAttacking(PlayerEntity target) {
        // True if the target is swinging their main hand (attacking), regardless of their air/ground state.
        return target.handSwinging && target.getActiveHand() == Hand.MAIN_HAND;
    }

    private static boolean isGettingComboedOrEatingOrLookingAway(PlayerEntity target) {
        // If target is eating, or looking away (yaw diff > 60 deg), or not swinging main hand.
        boolean isEating = target.isUsingItem() &&
                target.getActiveHand() == Hand.OFF_HAND &&
                target.getStackInHand(Hand.OFF_HAND).isFood();

        double yawDiff = Math.abs(
                wrapDegrees(
                        target.getYaw() - getYawTo(client.player, target)
                )
        );
        boolean lookingAway = yawDiff > 60;

        // Not attacking if not swinging main hand.
        boolean notAttacking = !target.handSwinging || target.getActiveHand() != Hand.MAIN_HAND;

        return isEating || lookingAway || notAttacking;
    }

    // Vanilla-style attack using doAttack() directly (access widener)
    private static void doAttackVanilla() {
        if (client != null && client.player != null) {
            client.doAttack();
        }
    }

    /**
     * Humanized delay: log-normal random, autocorrelated, always in [min, max].
     */
    private static long humanizedDelay(int min, int max, DelayType type) {
        double mean = Math.log((min + max) / 2.0);
        double stddev = 0.2; // tweak for realism
        long delay;
        do {
            delay = Math.round(Math.exp(mean + stddev * RANDOM.nextGaussian()));
        } while (delay < min || delay > max);

        // Autocorrelation: blend with last for this type
        long last = getLastDelay(type);
        if (last > 0) {
            double memoryWeight = 0.7; // 0 = no memory, 1 = full memory
            delay = Math.round(memoryWeight * last + (1.0 - memoryWeight) * delay);
            // Clamp after blending, in case blend goes outside range
            if (delay < min) delay = min;
            if (delay > max) delay = max;
        }
        setLastDelay(type, delay);

        // Tiny random jitter (simulate hand tremor)
        delay += RANDOM.nextInt(7) - 3; // -3 to +3 ms
        if (delay < min) delay = min;
        if (delay > max) delay = max;
        return delay;
    }

    private enum DelayType {
        GROUND_COMBO,
        GROUND_COMBO_SHORT,
        GROUND_ATTACKING,
        POST_EAT,
        FIRST_ATTACK,
        AIR_DESCENT_EXTRA,
        AIR_DESCENT_MINIMAL
    }

    private static long getLastDelay(DelayType type) {
        switch (type) {
            case GROUND_COMBO: return lastGroundComboDelay;
            case GROUND_COMBO_SHORT: return lastGroundShortComboDelay;
            case GROUND_ATTACKING: return lastGroundAttackingDelay;
            case POST_EAT: return lastPostEatDelay;
            case FIRST_ATTACK: return lastFirstAttackDelay;
            case AIR_DESCENT_EXTRA: return lastAirDescentExtraDelay;
            case AIR_DESCENT_MINIMAL: return lastAirDescentMinimalDelay;
            default: return -1;
        }
    }

    private static void setLastDelay(DelayType type, long value) {
        switch (type) {
            case GROUND_COMBO: lastGroundComboDelay = value; break;
            case GROUND_COMBO_SHORT: lastGroundShortComboDelay = value; break;
            case GROUND_ATTACKING: lastGroundAttackingDelay = value; break;
            case POST_EAT: lastPostEatDelay = value; break;
            case FIRST_ATTACK: lastFirstAttackDelay = value; break;
            case AIR_DESCENT_EXTRA: lastAirDescentExtraDelay = value; break;
            case AIR_DESCENT_MINIMAL: lastAirDescentMinimalDelay = value; break;
        }
    }

    private static boolean shouldApplyExtraDelay(PlayerEntity target) {
        ItemStack offhand = target.getStackInHand(Hand.OFF_HAND);
        boolean targetIsEating = target.isUsingItem() &&
                target.getActiveHand() == Hand.OFF_HAND &&
                offhand.isFood();

        double yawDiff = Math.abs(
                wrapDegrees(
                        target.getYaw() - getYawTo(client.player, target)
                )
        );
        boolean lookingAway = yawDiff > 60;

        return targetIsEating || lookingAway;
    }

    private static float getYawTo(PlayerEntity source, PlayerEntity target) {
        double dx = source.getX() - target.getX();
        double dz = source.getZ() - target.getZ();
        return (float) Math.toDegrees(Math.atan2(-dx, dz));
    }

    private static float wrapDegrees(double degrees) {
        degrees = degrees % 360.0;
        if (degrees >= 180.0) degrees -= 360.0;
        if (degrees < -180.0) degrees += 360.0;
        return (float) degrees;
    }
}