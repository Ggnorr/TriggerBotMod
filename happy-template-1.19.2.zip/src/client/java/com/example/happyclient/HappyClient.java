package com.example.happyclient;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SwordItem;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import org.lwjgl.glfw.GLFW;
import java.util.Random;

public class HappyClient implements ClientModInitializer {
    private static final MinecraftClient client = MinecraftClient.getInstance();
    private static boolean enabled = false;
    private static KeyBinding toggleKey;
    private static boolean wasOnTarget = false;
    private static long postEatDelayUntil = 0L; // ms
    private static final Random RANDOM = new Random();

    // Ground delays (no logic except randomization)
    private static long nextGroundAttackAllowedAt = 0L;

    private static final int POST_EAT_DELAY_MIN = 65;
    private static final int POST_EAT_DELAY_MAX = 70;

    private static final int FIRST_ATTACK_REACTION_MIN = 36;
    private static final int FIRST_ATTACK_REACTION_MAX = 55;

    // Jump/descent delays memory
    private static long nextAirAttackAllowedAt = 0L;
    private static boolean lastWasDescentAttack = false;

    // Memory for autocorrelation for each delay type
    private static long lastGroundAttackDelay = -1L;
    private static long lastPostEatDelay = -1L;
    private static long lastFirstAttackDelay = -1L;
    private static long lastAirDescentExtraDelay = -1L;
    private static long lastAirDescentMinimalDelay = -1L;

    // For first attack logic
    private static boolean waitingFirstAttack = false;
    private static long firstAttackScheduledFor = 0L;

    @Override
    public void onInitializeClient() {
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.triggerbotlegit.toggle",
                GLFW.GLFW_KEY_LEFT_ALT,
                "category.triggerbotlegit"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            // Toggle key logic
            while (toggleKey.wasPressed()) {
                enabled = !enabled;
                if (client.player != null) {
                    client.player.sendMessage(
                        net.minecraft.text.Text.of("TriggerBot: " + (enabled ? "ON" : "OFF")), true
                    );
                }
            }

            if (!enabled || client.player == null || client.crosshairTarget == null) {
                wasOnTarget = false;
                lastWasDescentAttack = false;
                waitingFirstAttack = false;
                return;
            }

            // Only if holding a sword
            ItemStack mainHand = client.player.getMainHandStack();
            if (!(mainHand.getItem() instanceof SwordItem)) {
                wasOnTarget = false;
                lastWasDescentAttack = false;
                waitingFirstAttack = false;
                return;
            }

            // Only attack players
            boolean onTarget = false;
            PlayerEntity targetPlayer = null;
            if (client.crosshairTarget.getType() == HitResult.Type.ENTITY) {
                Entity target = ((EntityHitResult) client.crosshairTarget).getEntity();
                if (target instanceof PlayerEntity && target != client.player) {
                    onTarget = true;
                    targetPlayer = (PlayerEntity) target;
                }
            }

            // Don't attack while eating from offhand
            ItemStack offhand = client.player.getStackInHand(Hand.OFF_HAND);
            boolean isEating = client.player.isUsingItem() &&
                               client.player.getActiveHand() == Hand.OFF_HAND &&
                               offhand.isFood();
            if (isEating) {
                postEatDelayUntil = System.currentTimeMillis() + humanizedDelay(POST_EAT_DELAY_MIN, POST_EAT_DELAY_MAX, DelayType.POST_EAT);
                wasOnTarget = false;
                lastWasDescentAttack = false;
                waitingFirstAttack = false;
                return;
            }

            // Wait post-eating delay before attacking again
            if (System.currentTimeMillis() < postEatDelayUntil) {
                wasOnTarget = false;
                lastWasDescentAttack = false;
                waitingFirstAttack = false;
                return;
            }

            boolean onGround = client.player.isOnGround();
            double playerVelY = client.player.getVelocity().y;
            long now = System.currentTimeMillis();

            if (onGround) {
                lastWasDescentAttack = false;

                if (playerVelY > 0.08) { // Ascending
                    wasOnTarget = false;
                    waitingFirstAttack = false;
                    return;
                }

                // FIRST ATTACK HUMANIZED REACTION TIME
                if (onTarget && !wasOnTarget && now >= nextGroundAttackAllowedAt) {
                    if (!waitingFirstAttack) {
                        // Schedule the first attack with a humanized delay
                        long firstDelay = humanizedDelay(FIRST_ATTACK_REACTION_MIN, FIRST_ATTACK_REACTION_MAX, DelayType.FIRST_ATTACK);
                        firstAttackScheduledFor = now + firstDelay;
                        waitingFirstAttack = true;
                        wasOnTarget = onTarget;
                        return;
                    } else if (waitingFirstAttack && now < firstAttackScheduledFor) {
                        wasOnTarget = onTarget;
                        return;
                    } else if (waitingFirstAttack && now >= firstAttackScheduledFor) {
                        // Time to attack
                        doAttackVanilla();
                        nextGroundAttackAllowedAt = now + groundAttackDelayWeighted();
                        waitingFirstAttack = false;
                    }
                } else if (onTarget && wasOnTarget && now >= nextGroundAttackAllowedAt) {
                    // Subsequent attacks: always use weighted delay, no logic except randomization
                    doAttackVanilla();
                    nextGroundAttackAllowedAt = now + groundAttackDelayWeighted();
                } else {
                    waitingFirstAttack = false;
                }
                wasOnTarget = onTarget;
            } else {
                waitingFirstAttack = false;
                // In air (jump/descent)
                if (playerVelY < -0.01) { // Descent phase - as soon as possible
                    if (onTarget && !lastWasDescentAttack) {
                        long extraDelay = 0;
                        if (targetPlayer != null && isTargetEating(targetPlayer)) {
                            extraDelay = airDescentEatingDelayWeighted();
                        } else {
                            extraDelay = airDescentNonEatingDelayWeighted();
                        }
                        nextAirAttackAllowedAt = now + extraDelay;
                        lastWasDescentAttack = true;
                    }
                    // Attack only after the random delay, and only once per descent
                    if (lastWasDescentAttack && now >= nextAirAttackAllowedAt && onTarget) {
                        doAttackVanilla();
                    }
                } else {
                    lastWasDescentAttack = false;
                }
                wasOnTarget = onTarget;
            }
        });
    }

    // Weighted randomization for ground attack delay
    private static long groundAttackDelayWeighted() {
        int roll = RANDOM.nextInt(100);
        if (roll < 80) {
            return humanizedDelay(595, 627, DelayType.GROUND_ATTACK);
        } else if (roll < 99) {
            return humanizedDelay(550, 590, DelayType.GROUND_ATTACK);
        } else {
            return humanizedDelay(480, 520, DelayType.GROUND_ATTACK);
        }
    }

    // Weighted randomization for air/descent attack delay (if eating)
    private static long airDescentEatingDelayWeighted() {
        int roll = RANDOM.nextInt(100);
        if (roll < 80) {
            return humanizedDelay(70, 115, DelayType.AIR_DESCENT_EXTRA);
        } else if (roll < 99) {
            return humanizedDelay(40, 60, DelayType.AIR_DESCENT_EXTRA);
        } else {
            return humanizedDelay(120, 140, DelayType.AIR_DESCENT_EXTRA);
        }
    }

    // Weighted randomization for air/descent attack delay (if not eating)
    private static long airDescentNonEatingDelayWeighted() {
        int roll = RANDOM.nextInt(100);
        if (roll < 80) {
            return humanizedDelay(15, 50, DelayType.AIR_DESCENT_MINIMAL);
        } else if (roll < 99) {
            return humanizedDelay(55, 70, DelayType.AIR_DESCENT_MINIMAL);
        } else {
            return humanizedDelay(70, 100, DelayType.AIR_DESCENT_MINIMAL);
        }
    }

    // Is the target eating (for descent delay)
    private static boolean isTargetEating(PlayerEntity target) {
        return target.isUsingItem() &&
                target.getActiveHand() == Hand.OFF_HAND &&
                target.getStackInHand(Hand.OFF_HAND).isFood();
    }

    // Vanilla-style attack using doAttack() directly (access widener)
    private static void doAttackVanilla() {
        if (client != null && client.player != null) {
            client.doAttack();
        }
    }

    /**
     * Humanized delay: log-normal random, autocorrelated, always in [min, max].
     */
    private static long humanizedDelay(int min, int max, DelayType type) {
        double mean = Math.log((min + max) / 2.0);
        double stddev = 0.2;
        long delay;
        do {
            delay = Math.round(Math.exp(mean + stddev * RANDOM.nextGaussian()));
        } while (delay < min || delay > max);

        // Autocorrelation: blend with last for this type
        long last = getLastDelay(type);
        if (last > 0) {
            double memoryWeight = 0.7;
            delay = Math.round(memoryWeight * last + (1.0 - memoryWeight) * delay);
            if (delay < min) delay = min;
            if (delay > max) delay = max;
        }
        setLastDelay(type, delay);

        // Tiny random jitter (simulate hand tremor)
        delay += RANDOM.nextInt(7) - 3; // -3 to +3 ms
        if (delay < min) delay = min;
        if (delay > max) delay = max;
        return delay;
    }

    private enum DelayType {
        GROUND_ATTACK,
        POST_EAT,
        FIRST_ATTACK,
        AIR_DESCENT_EXTRA,
        AIR_DESCENT_MINIMAL
    }

    private static long getLastDelay(DelayType type) {
        switch (type) {
            case GROUND_ATTACK: return lastGroundAttackDelay;
            case POST_EAT: return lastPostEatDelay;
            case FIRST_ATTACK: return lastFirstAttackDelay;
            case AIR_DESCENT_EXTRA: return lastAirDescentExtraDelay;
            case AIR_DESCENT_MINIMAL: return lastAirDescentMinimalDelay;
            default: return -1;
        }
    }

    private static void setLastDelay(DelayType type, long value) {
        switch (type) {
            case GROUND_ATTACK: lastGroundAttackDelay = value; break;
            case POST_EAT: lastPostEatDelay = value; break;
            case FIRST_ATTACK: lastFirstAttackDelay = value; break;
            case AIR_DESCENT_EXTRA: lastAirDescentExtraDelay = value; break;
            case AIR_DESCENT_MINIMAL: lastAirDescentMinimalDelay = value; break;
        }
    }

    private static float getYawTo(PlayerEntity source, PlayerEntity target) {
        double dx = source.getX() - target.getX();
        double dz = source.getZ() - target.getZ();
        return (float) Math.toDegrees(Math.atan2(-dx, dz));
    }

    private static float wrapDegrees(double degrees) {
        degrees = degrees % 360.0;
        if (degrees >= 180.0) degrees -= 360.0;
        if (degrees < -180.0) degrees += 360.0;
        return (float) degrees;
    }
}