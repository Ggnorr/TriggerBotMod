package com.example.happyclient.mixin;

import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(TargetClass.class) // Replace with the actual class you want to inject into
public class MyMixin {
    @Inject(method = "targetMethodName", at = @At("HEAD")) // Replace as needed
    private void onTargetMethod(CallbackInfo ci) {
        MinecraftClient.getInstance().doAttack();
    }
}