package com.example.happyclient;

public class IntentUtils {
    public static void sendLeftClickIntent() {
        try {
            Class<?> activityThread = Class.forName("android.app.ActivityThread");
            Object app = activityThread.getMethod("currentApplication").invoke(null);
            android.content.Context context = (android.content.Context) app;
            android.content.Intent intent = new android.content.Intent("com.example.SIMULATE_LEFT_CLICK");
            context.sendBroadcast(intent);
        } catch (Exception e) {
            System.out.println("[HappyClient] Failed to send left click intent: " + e);
        }
    }
}