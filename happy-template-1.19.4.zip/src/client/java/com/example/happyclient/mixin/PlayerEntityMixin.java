package com.example.happyclient.mixin;

import com.example.happyclient.HappyClient;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * This mixin hooks into the player damage event for the local player.
 * When the attacker is a player, the victim is on the ground, and the attacker is airborne and falling,
 * it triggers the crit punish logic in HappyClient.
 */
@Mixin(PlayerEntity.class)
public class PlayerEntityMixin {
    @Inject(method = "damage", at = @At("HEAD"))
    private void onDamage(DamageSource source, float amount, CallbackInfoReturnable<Boolean> cir) {
        PlayerEntity self = (PlayerEntity)(Object)this;
        // Only care about local client player on the client
        if (!self.world.isClient) return;
        if (!self.equals(net.minecraft.client.MinecraftClient.getInstance().player)) return;

        // Only trigger on actual player attacks
        if (source.getAttacker() instanceof PlayerEntity) {
            PlayerEntity attacker = (PlayerEntity) source.getAttacker();

            // Was I on the ground? Was attacker falling (real crit)?
            if (self.isOnGround() && !attacker.isOnGround() && attacker.getVelocity().y < -0.1) {
                HappyClient.activateCritPunish();
            }
        }
    }
}