package com.example.happyclient.mixin;

import com.example.happyclient.HappyClient;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(PlayerEntity.class)
public class PlayerEntityMixin {
    // Intermediary name for damage(DamageSource, float) in 1.19.4 is method_6098
    @Inject(method = "method_6098", at = @At("HEAD"))
    private void onDamage(DamageSource source, float amount, CallbackInfoReturnable<Boolean> cir) {
        PlayerEntity self = (PlayerEntity)(Object)this;
        // Only care about client player
        if (!self.world.isClient) return;
        if (!self.equals(net.minecraft.client.MinecraftClient.getInstance().player)) return;

        if (source.getAttacker() instanceof PlayerEntity) {
            PlayerEntity attacker = (PlayerEntity) source.getAttacker();
            if (self.isOnGround() && !attacker.isOnGround() && attacker.getVelocity().y < -0.1) {
                HappyClient.activateCritPunish();
            }
        }
    }
}