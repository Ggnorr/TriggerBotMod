package com.example.happyclient;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;

import java.util.Random;

public class HappyClient implements ClientModInitializer {
    private static final Random RANDOM = new Random();
    private static long nextAttackTime = 0L;
    private static boolean wasEating = false;
    private static boolean enabled = true;
    private static KeyBinding toggleKey;
    private boolean attackKeyPressedLastTick = false;

    // Punish crit state
    private static boolean punishCritActive = false;
    private static long lastCritTime = 0L;
    private static final long PUNISH_CRIT_TIMEOUT = 2000; // 2 seconds after last crit

    // Health tracking for crit detection
    private float lastHealth = -1f;

    @Override
    public void onInitializeClient() {
        // Register keybind: Alt (left) to toggle
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.triggerbot.toggle",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_LEFT_ALT,
                "category.triggerbot"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (toggleKey.wasPressed()) {
                enabled = !enabled;
                if (client.player != null) {
                    client.player.sendMessage(
                        enabled ?
                            net.minecraft.text.Text.literal("TriggerBot enabled") :
                            net.minecraft.text.Text.literal("TriggerBot disabled"),
                        false
                    );
                }
            }

            if (!enabled) {
                releaseAttackKey(client);
                return;
            }

            if (client.player == null || client.world == null) {
                releaseAttackKey(client);
                return;
            }
            if (client.currentScreen != null) {
                releaseAttackKey(client);
                return;
            }

            ClientPlayerEntity player = client.player;

            // --- Crit Detection Logic (Simple) ---
            float currentHealth = player.getHealth();
            long now = System.currentTimeMillis();

            // On first run, initialize lastHealth
            if (lastHealth < 0f) lastHealth = currentHealth;

            // Detect damage taken
            if (currentHealth < lastHealth) {
                // Try to find attacker (nearest player in melee range)
                Entity attacker = findPotentialAttacker(client, player);
                if (attacker instanceof PlayerEntity) {
                    boolean airborne = !attacker.isOnGround();
                    boolean descending = attacker.getVelocity().y < 0.0;
                    boolean recentlyJumped = Math.abs(attacker.getVelocity().y) > 0.08; // Small y-velocity threshold for jumps
                    // If attacker is airborne, descending, or just jumped/fell: assume crit
                    if (airborne || descending || recentlyJumped) {
                        punishCritActive = true;
                        lastCritTime = now;
                    }
                }
            }
            lastHealth = currentHealth;

            // Timeout for punish crit
            if (punishCritActive && now - lastCritTime > PUNISH_CRIT_TIMEOUT) {
                punishCritActive = false;
            }

            boolean isOnGround = player.isOnGround();
            boolean isDescending = !isOnGround && player.getVelocity().y < 0;

            // Don't attack if eating (either hand)
            if (isEating(player)) {
                wasEating = true;
                nextAttackTime = now + 70;
                releaseAttackKey(client);
                return;
            }

            // Post-eat delay
            if (wasEating) {
                wasEating = false;
                nextAttackTime = now + 65 + RANDOM.nextInt(6); // 65-70ms
            }

            boolean shouldClick = false;
            float cooldownProgress = player.getAttackCooldownProgress(0);

            if (client.crosshairTarget instanceof EntityHitResult entityHit) {
                Entity target = entityHit.getEntity();
                if (isValidTarget(target, player)) {
                    // Only attack if cooldown is between 0.8 and 1.0 (80% to 100%)
                    if (cooldownProgress >= 0.8f && cooldownProgress <= 1.0f) {
                        // Ground logic
                        if (isOnGround) {
                            long delay = punishCritActive ? getPunishCritDelay() : getNextGroundAttackDelay();
                            if (now >= nextAttackTime) {
                                shouldClick = true;
                                nextAttackTime = now + delay;
                            }
                        }
                        // Descent logic
                        else if (isDescending) {
                            if (now >= nextAttackTime) {
                                shouldClick = true;
                                nextAttackTime = now + getNextDescentAttackDelay(target, player);
                            }
                        }
                    }
                }
            } else {
                nextAttackTime = now + 25;
            }

            KeyBinding attackKey = client.options.attackKey;
            if (shouldClick) {
                if (!attackKey.isPressed()) {
                    KeyBinding.setKeyPressed(attackKey.getDefaultKey(), true);
                    attackKeyPressedLastTick = true;
                }
            } else {
                releaseAttackKey(client);
            }
        });
    }

    private void releaseAttackKey(MinecraftClient client) {
        if (attackKeyPressedLastTick && client != null) {
            KeyBinding attackKey = client.options.attackKey;
            KeyBinding.setKeyPressed(attackKey.getDefaultKey(), false);
            attackKeyPressedLastTick = false;
        }
    }

    // Accepts any entity, but only attacks players if the player is holding a sword in main hand
    private boolean isValidTarget(Entity target, ClientPlayerEntity self) {
        if (target == self) return false;
        if (!(target instanceof LivingEntity) || !((LivingEntity) target).isAlive()) return false;
        if (target instanceof PlayerEntity) {
            ItemStack main = self.getMainHandStack();
            return main.getItem().getTranslationKey().contains("sword");
        }
        return true;
    }

    // Checks if player is eating food (either hand)
    private boolean isEating(ClientPlayerEntity player) {
        ItemStack main = player.getMainHandStack();
        ItemStack off = player.getOffHandStack();
        return (main.isFood() && player.isUsingItem() && player.getActiveHand() == Hand.MAIN_HAND) ||
                (off.isFood() && player.isUsingItem() && player.getActiveHand() == Hand.OFF_HAND);
    }

    // Ground delay: 97% 570-600ms, 3% 550-570ms
    private long getNextGroundAttackDelay() {
        if (RANDOM.nextDouble() < 0.97) {
            return 570 + RANDOM.nextInt(31); // 570–600 inclusive
        } else {
            return 550 + RANDOM.nextInt(21); // 550–570 inclusive
        }
    }

    // Punish crit ground delay: 605–627ms
    private long getPunishCritDelay() {
        return 605 + RANDOM.nextInt(23); // 605–627ms inclusive
    }

    // Jump descent: 
    // If target is eating OR not looking at us OR sprinting and not looking: 120–170ms
    // Otherwise: 15–50ms
    private long getNextDescentAttackDelay(Entity target, ClientPlayerEntity self) {
        if (target instanceof PlayerEntity) {
            PlayerEntity p = (PlayerEntity) target;
            if (isPlayerEating(p) || !isPlayerLookingAtMe(p, self) || (p.isSprinting() && !isPlayerLookingAtMe(p, self))) {
                return 120 + RANDOM.nextInt(51); // 120–170ms
            }
        }
        return 15 + RANDOM.nextInt(36); // 15–50ms
    }

    // For enemy eating check
    private boolean isPlayerEating(PlayerEntity player) {
        ItemStack stack = player.getMainHandStack();
        if (stack.isFood() && player.isUsingItem()) return true;
        stack = player.getOffHandStack();
        return stack.isFood() && player.isUsingItem();
    }

    // For enemy looking direction check (~60deg cone)
    private boolean isPlayerLookingAtMe(PlayerEntity target, ClientPlayerEntity self) {
        double dx = self.getX() - target.getX();
        double dz = self.getZ() - target.getZ();
        double yawToSelf = MathHelper.wrapDegrees(Math.toDegrees(Math.atan2(-dx, dz)));
        double yawDiff = Math.abs(MathHelper.wrapDegrees(target.getYaw() - yawToSelf));
        return yawDiff < 30.0; // 60-degree cone
    }

    // Attempt to find potential melee attacker near the player (for crit detection)
    private Entity findPotentialAttacker(MinecraftClient client, ClientPlayerEntity self) {
        double minDist = 3.5; // melee range
        Entity best = null;
        for (Entity e : client.world.getEntities()) {
            if (e == self) continue;
            if (!(e instanceof PlayerEntity)) continue;
            if (!e.isAlive()) continue;
            double dist = e.squaredDistanceTo(self);
            if (dist < minDist * minDist) {
                minDist = Math.sqrt(dist);
                best = e;
            }
        }
        return best;
    }
}