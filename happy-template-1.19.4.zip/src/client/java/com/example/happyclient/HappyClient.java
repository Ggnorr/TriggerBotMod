package com.example.happyclient;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SwordItem;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import org.lwjgl.glfw.GLFW;
import java.util.Random;

public class HappyClient implements ClientModInitializer {
    private static final MinecraftClient client = MinecraftClient.getInstance();
    private static boolean enabled = false;
    private static KeyBinding toggleKey;
    private static boolean wasOnTarget = false;
    private static long postEatDelayUntil = 0L; // ms
    private static final Random RANDOM = new Random();

    // Ground delays
    private static long nextGroundAttackAllowedAt = 0L;
    private static final int GROUND_DELAY_COMBO_MIN = 570;
    private static final int GROUND_DELAY_COMBO_MAX = 590;
    private static final int GROUND_DELAY_COMBO_SHORT_MIN = 550;
    private static final int GROUND_DELAY_COMBO_SHORT_MAX = 570;
    private static final int GROUND_DELAY_ATTACKING_MIN = 600;
    private static final int GROUND_DELAY_ATTACKING_MAX = 627;

    private static final int POST_EAT_DELAY_MIN = 65;
    private static final int POST_EAT_DELAY_MAX = 70;

    // Jump/descent delays
    private static long nextAirAttackAllowedAt = 0L;
    private static boolean lastWasDescentAttack = false;

    @Override
    public void onInitializeClient() {
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.triggerbotlegit.toggle",
                GLFW.GLFW_KEY_LEFT_ALT,
                "category.triggerbotlegit"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            // Toggle key logic
            while (toggleKey.wasPressed()) {
                enabled = !enabled;
                if (client.player != null) {
                    client.player.sendMessage(
                        net.minecraft.text.Text.of("TriggerBot: " + (enabled ? "ON" : "OFF")), true
                    );
                }
            }

            if (!enabled || client.player == null || client.crosshairTarget == null) {
                releaseAttackKey();
                wasOnTarget = false;
                lastWasDescentAttack = false;
                return;
            }

            // Only if holding a sword
            ItemStack mainHand = client.player.getMainHandStack();
            if (!(mainHand.getItem() instanceof SwordItem)) {
                releaseAttackKey();
                wasOnTarget = false;
                lastWasDescentAttack = false;
                return;
            }

            // Only attack players
            boolean onTarget = false;
            PlayerEntity targetPlayer = null;
            if (client.crosshairTarget.getType() == HitResult.Type.ENTITY) {
                Entity target = ((EntityHitResult) client.crosshairTarget).getEntity();
                if (target instanceof PlayerEntity && target != client.player) {
                    onTarget = true;
                    targetPlayer = (PlayerEntity) target;
                }
            }

            // Don't attack while eating from offhand
            ItemStack offhand = client.player.getStackInHand(Hand.OFF_HAND);
            boolean isEating = client.player.isUsingItem() &&
                               client.player.getActiveHand() == Hand.OFF_HAND &&
                               offhand.isFood();
            if (isEating) {
                releaseAttackKey();
                wasOnTarget = false;
                lastWasDescentAttack = false;
                postEatDelayUntil = System.currentTimeMillis() + uniformDelay(POST_EAT_DELAY_MIN, POST_EAT_DELAY_MAX);
                return;
            }

            // Wait post-eating delay before attacking again
            if (System.currentTimeMillis() < postEatDelayUntil) {
                releaseAttackKey();
                wasOnTarget = false;
                lastWasDescentAttack = false;
                return;
            }

            boolean onGround = client.player.isOnGround();
            double playerVelY = client.player.getVelocity().y;
            long now = System.currentTimeMillis();

            if (onGround) {
                lastWasDescentAttack = false;

                if (playerVelY > 0.08) { // Ascending
                    releaseAttackKey();
                    wasOnTarget = false;
                    return;
                }

                if (onTarget && !wasOnTarget && now >= nextGroundAttackAllowedAt) {
                    if (targetPlayer != null) {
                        long delay;
                        if (isTargetAttacking(targetPlayer)) {
                            // If the enemy is attacking back with main hand, use 600-627ms delay
                            delay = uniformDelay(GROUND_DELAY_ATTACKING_MIN, GROUND_DELAY_ATTACKING_MAX);
                        } else if (isGettingComboedOrEatingOrLookingAway(targetPlayer)) {
                            // If the enemy is getting comboed, eating, or looking away
                            int chance = RANDOM.nextInt(100);
                            if (chance < 95) { // 95% chance
                                delay = uniformDelay(GROUND_DELAY_COMBO_MIN, GROUND_DELAY_COMBO_MAX);
                            } else { // 5% chance
                                delay = uniformDelay(GROUND_DELAY_COMBO_SHORT_MIN, GROUND_DELAY_COMBO_SHORT_MAX);
                            }
                        } else {
                            // Fallback to a reasonable delay (use combo delay logic)
                            delay = uniformDelay(GROUND_DELAY_COMBO_MIN, GROUND_DELAY_COMBO_MAX);
                        }
                        pressAttackKey();
                        nextGroundAttackAllowedAt = now + delay;
                    } else {
                        // Default combo delay if no target
                        pressAttackKey();
                        nextGroundAttackAllowedAt = now + uniformDelay(GROUND_DELAY_COMBO_MIN, GROUND_DELAY_COMBO_MAX);
                    }
                } else {
                    releaseAttackKey();
                }
                wasOnTarget = onTarget;
            } else {
                // In air (jump/descent) -- your original jump logic is preserved!
                if (playerVelY < -0.08) { // Descent phase
                    if (onTarget && !lastWasDescentAttack) {
                        long extraDelay = 0;
                        if (targetPlayer != null && shouldApplyExtraDelay(targetPlayer)) {
                            extraDelay = uniformDelay(120, 150);
                        } else {
                            extraDelay = uniformDelay(15, 50);
                        }
                        nextAirAttackAllowedAt = now + extraDelay;
                        lastWasDescentAttack = true;
                    }
                    // Attack only after the random delay, and only once per descent
                    if (lastWasDescentAttack && now >= nextAirAttackAllowedAt && onTarget) {
                        pressAttackKey();
                    } else {
                        releaseAttackKey();
                    }
                } else {
                    lastWasDescentAttack = false;
                    releaseAttackKey();
                }
                wasOnTarget = onTarget;
            }
        });
    }

    private static boolean isTargetAttacking(PlayerEntity target) {
        // True if the target is swinging their main hand (attacking), regardless of their air/ground state.
        return target.handSwinging && target.getActiveHand() == Hand.MAIN_HAND;
    }

    private static boolean isGettingComboedOrEatingOrLookingAway(PlayerEntity target) {
        // If target is eating, or looking away (yaw diff > 60 deg), or not swinging main hand.
        boolean isEating = target.isUsingItem() &&
                target.getActiveHand() == Hand.OFF_HAND &&
                target.getStackInHand(Hand.OFF_HAND).isFood();

        double yawDiff = Math.abs(
                wrapDegrees(
                        target.getYaw() - getYawTo(client.player, target)
                )
        );
        boolean lookingAway = yawDiff > 60;

        // Not attacking if not swinging main hand.
        boolean notAttacking = !target.handSwinging || target.getActiveHand() != Hand.MAIN_HAND;

        return isEating || lookingAway || notAttacking;
    }

    private static void pressAttackKey() {
        client.options.attackKey.setPressed(true);
    }

    private static void releaseAttackKey() {
        client.options.attackKey.setPressed(false);
    }

    private static long uniformDelay(int min, int max) {
        return min + RANDOM.nextInt((max - min) + 1);
    }

    private static boolean shouldApplyExtraDelay(PlayerEntity target) {
        ItemStack offhand = target.getStackInHand(Hand.OFF_HAND);
        boolean targetIsEating = target.isUsingItem() &&
                target.getActiveHand() == Hand.OFF_HAND &&
                offhand.isFood();

        double yawDiff = Math.abs(
                wrapDegrees(
                        target.getYaw() - getYawTo(client.player, target)
                )
        );
        boolean lookingAway = yawDiff > 60;

        return targetIsEating || lookingAway;
    }

    private static float getYawTo(PlayerEntity source, PlayerEntity target) {
        double dx = source.getX() - target.getX();
        double dz = source.getZ() - target.getZ();
        return (float) Math.toDegrees(Math.atan2(-dx, dz));
    }

    private static float wrapDegrees(double degrees) {
        degrees = degrees % 360.0;
        if (degrees >= 180.0) degrees -= 360.0;
        if (degrees < -180.0) degrees += 360.0;
        return (float) degrees;
    }
}