package com.example.triggerbotlegit;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.sound.SoundInstance;
import net.minecraft.sound.SoundEvents;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SwordItem;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import org.lwjgl.glfw.GLFW;
import java.util.Random;

public class TriggerBotLegitMod implements ClientModInitializer {
    private static final MinecraftClient client = MinecraftClient.getInstance();
    private static boolean enabled = false;
    private static KeyBinding toggleKey;
    private static boolean wasOnTarget = false;
    private static long postEatDelayUntil = 0L; // ms
    private static final Random RANDOM = new Random();

    // Humanized delays for ground
    private static long nextGroundAttackAllowedAt = 0L;
    private static final int GROUND_DELAY_SHORT_CHANCE = 3; // 3%
    private static final int GROUND_DELAY_SHORT_MIN = 550;
    private static final int GROUND_DELAY_SHORT_MAX = 570;
    private static final int GROUND_DELAY_LONG_MIN = 585;
    private static final int GROUND_DELAY_LONG_MAX = 600;

    private static final int POST_EAT_DELAY_MIN = 65;
    private static final int POST_EAT_DELAY_MAX = 70;

    // Jump/descent delays
    private static long nextAirAttackAllowedAt = 0L;
    private static boolean lastWasDescentAttack = false;

    // Crit detection state
    private static boolean punishCritsActive = false;
    private static long lastCritReceivedAt = 0L;
    private static final long CRIT_PUNISH_DURATION_MS = 2000L;
    private static final int PUNISH_CRIT_GROUND_MIN = 600;
    private static final int PUNISH_CRIT_GROUND_MAX = 627;

    // Sound detection state
    private static boolean heardCritSoundThisTick = false;

    @Override
    public void onInitializeClient() {
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.triggerbotlegit.toggle",
                GLFW.GLFW_KEY_LEFT_ALT,
                "category.triggerbotlegit"
        ));

        // Listen for crit sound events
        client.getSoundManager().registerListener(sound -> {
            // Only care about crit sound
            if (sound.getSound().getId().equals(SoundEvents.ENTITY_PLAYER_ATTACK_CRIT.getId())) {
                heardCritSoundThisTick = true;
            }
        });

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            // Toggle key logic
            while (toggleKey.wasPressed()) {
                enabled = !enabled;
                if (client.player != null) {
                    client.player.sendMessage(
                        net.minecraft.text.Text.of("TriggerBot: " + (enabled ? "ON" : "OFF")), true
                    );
                }
            }

            if (!enabled || client.player == null || client.crosshairTarget == null) {
                releaseAttackKey();
                wasOnTarget = false;
                lastWasDescentAttack = false;
                heardCritSoundThisTick = false;
                return;
            }

            // Only if holding a sword
            ItemStack mainHand = client.player.getMainHandStack();
            if (!(mainHand.getItem() instanceof SwordItem)) {
                releaseAttackKey();
                wasOnTarget = false;
                lastWasDescentAttack = false;
                heardCritSoundThisTick = false;
                return;
            }

            // Only attack players
            boolean onTarget = false;
            PlayerEntity targetPlayer = null;
            if (client.crosshairTarget.getType() == HitResult.Type.ENTITY) {
                Entity target = ((EntityHitResult) client.crosshairTarget).getEntity();
                if (target instanceof PlayerEntity && target != client.player) {
                    onTarget = true;
                    targetPlayer = (PlayerEntity) target;
                }
            }

            // Don't attack while eating from offhand
            ItemStack offhand = client.player.getStackInHand(Hand.OFF_HAND);
            boolean isEating = client.player.isUsingItem() &&
                               client.player.getActiveHand() == Hand.OFF_HAND &&
                               offhand.isFood();
            if (isEating) {
                releaseAttackKey();
                wasOnTarget = false;
                lastWasDescentAttack = false;
                heardCritSoundThisTick = false;
                // Set post-eat delay
                postEatDelayUntil = System.currentTimeMillis() + uniformDelay(POST_EAT_DELAY_MIN, POST_EAT_DELAY_MAX);
                return;
            }

            // Wait post-eating delay before attacking again
            if (System.currentTimeMillis() < postEatDelayUntil) {
                releaseAttackKey();
                wasOnTarget = false;
                lastWasDescentAttack = false;
                heardCritSoundThisTick = false;
                return;
            }

            boolean onGround = client.player.isOnGround();
            double playerVelY = client.player.getVelocity().y;
            long now = System.currentTimeMillis();

            // --- Detect "enemy crit" ---
            // If we're on the ground, the target is on the ground, and we hear the crit sound, punish.
            // If we're in the air, only punish if the enemy hits us while descending (from our knockback or his jump).
            if (punishCritsActive && (now - lastCritReceivedAt > CRIT_PUNISH_DURATION_MS)) {
                punishCritsActive = false;
            }

            boolean enemyIsOnGround = targetPlayer != null && targetPlayer.isOnGround();
            boolean enemyIsDescending = targetPlayer != null && targetPlayer.getVelocity().y < -0.08;

            // Disable crit sound detection if WE are jumping
            boolean selfIsJumping = !onGround && playerVelY > 0.08;

            // If we're on the ground, enemy is on the ground, and crit sound is heard, punish
            if (!punishCritsActive && onGround && enemyIsOnGround && heardCritSoundThisTick && !selfIsJumping) {
                punishCritsActive = true;
                lastCritReceivedAt = now;
            }

            // If enemy is descending (either jumping or from knockback), AND we are taking knockback (velocity.y < -0.08), punish
            if (!punishCritsActive && !onGround && enemyIsDescending && playerVelY < -0.08) {
                punishCritsActive = true;
                lastCritReceivedAt = now;
            }

            // Core attacking logic
            if (onGround) {
                lastWasDescentAttack = false;

                if (playerVelY > 0.08) { // Ascending
                    releaseAttackKey();
                    wasOnTarget = false;
                    heardCritSoundThisTick = false;
                    return;
                }

                if (onTarget && !wasOnTarget && now >= nextGroundAttackAllowedAt) {
                    if (punishCritsActive) {
                        pressAttackKey();
                        nextGroundAttackAllowedAt = now + uniformDelay(PUNISH_CRIT_GROUND_MIN, PUNISH_CRIT_GROUND_MAX);
                    } else {
                        pressAttackKey();
                        nextGroundAttackAllowedAt = now + humanizedGroundDelay();
                    }
                } else {
                    releaseAttackKey();
                }
                wasOnTarget = onTarget;
            } else {
                // In air
                if (playerVelY < -0.08) { // Descent phase
                    if (onTarget && !lastWasDescentAttack) {
                        long extraDelay = 0;
                        if (targetPlayer != null && shouldApplyExtraDelay(targetPlayer)) {
                            extraDelay = uniformDelay(120, 150);
                        } else {
                            extraDelay = uniformDelay(15, 50);
                        }
                        nextAirAttackAllowedAt = now + extraDelay;
                        lastWasDescentAttack = true;
                    }
                    // Attack only after the random delay, and only once per descent
                    if (lastWasDescentAttack && now >= nextAirAttackAllowedAt && onTarget) {
                        pressAttackKey();
                    } else {
                        releaseAttackKey();
                    }
                } else {
                    lastWasDescentAttack = false;
                    releaseAttackKey();
                }
                wasOnTarget = onTarget;
            }

            heardCritSoundThisTick = false; // Reset for next tick
        });
    }

    private static void pressAttackKey() {
        client.options.attackKey.setPressed(true);
    }
    private static void releaseAttackKey() {
        client.options.attackKey.setPressed(false);
    }

    private static long uniformDelay(int min, int max) {
        return min + RANDOM.nextInt((max - min) + 1);
    }

    /**
     * 97% chance: 585-600ms,
     * 3% chance: 550-570ms
     */
    private static long humanizedGroundDelay() {
        int chance = RANDOM.nextInt(100);
        if (chance < GROUND_DELAY_SHORT_CHANCE) {
            return uniformDelay(GROUND_DELAY_SHORT_MIN, GROUND_DELAY_SHORT_MAX);
        } else {
            return uniformDelay(GROUND_DELAY_LONG_MIN, GROUND_DELAY_LONG_MAX);
        }
    }

    /**
     * Returns true if the target is looking away from the player or is eating food.
     * "Looking away" means yaw difference > 60 degrees.
     */
    private static boolean shouldApplyExtraDelay(PlayerEntity target) {
        // Check if target is eating
        ItemStack offhand = target.getStackInHand(Hand.OFF_HAND);
        boolean targetIsEating = target.isUsingItem() &&
                target.getActiveHand() == Hand.OFF_HAND &&
                offhand.isFood();

        // Compute yaw difference
        double yawDiff = Math.abs(
                wrapDegrees(
                        target.getYaw() - getYawTo(client.player, target)
                )
        );
        boolean lookingAway = yawDiff > 60;

        return targetIsEating || lookingAway;
    }

    /**
     * Returns the yaw from target to source (for accurate facing)
     */
    private static float getYawTo(PlayerEntity source, PlayerEntity target) {
        double dx = source.getX() - target.getX();
        double dz = source.getZ() - target.getZ();
        return (float) Math.toDegrees(Math.atan2(-dx, dz));
    }

    /**
     * Normalize angle to [-180, 180]
     */
    private static float wrapDegrees(double degrees) {
        degrees = degrees % 360.0;
        if (degrees >= 180.0) degrees -= 360.0;
        if (degrees < -180.0) degrees += 360.0;
        return (float) degrees;
    }
}