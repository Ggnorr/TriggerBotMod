package com.example.happyclient;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import org.lwjgl.glfw.GLFW;

import java.util.Random;

public class HappyClient implements ClientModInitializer {

    private long lastAttackTime = 0L;
    private static final Random random = new Random();

    // Crit punish tracking
    private boolean critPunishActive = false;
    private int lastHurtTime = 0;

    // For event-driven crits
    private boolean wasFalling = false;
    private boolean critAttackScheduled = false;

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null || client.world == null) return;
            if (client.currentScreen != null) return;

            ClientPlayerEntity player = client.player;

            // Watch for damage (approximate for crit punish)
            if (player.hurtTime > 0) {
                if (player.hurtTime > lastHurtTime) {
                    critPunishActive = true;
                }
            } else {
                critPunishActive = false;
            }
            lastHurtTime = player.hurtTime;

            long window = client.getWindow().getHandle();
            boolean leftClickHeld = GLFW.glfwGetMouseButton(window, GLFW.GLFW_MOUSE_BUTTON_1) == GLFW.GLFW_PRESS;
            if (!leftClickHeld) {
                wasFalling = false;
                critAttackScheduled = false;
                return;
            }

            ItemStack main = player.getMainHandStack();
            if (!(main.getItem() == Items.WOODEN_SWORD ||
                  main.getItem() == Items.STONE_SWORD ||
                  main.getItem() == Items.IRON_SWORD ||
                  main.getItem() == Items.GOLDEN_SWORD ||
                  main.getItem() == Items.DIAMOND_SWORD ||
                  main.getItem() == Items.NETHERITE_SWORD)) {
                wasFalling = false;
                critAttackScheduled = false;
                return;
            }

            Entity target = client.targetedEntity;
            if (target != null && target != player) {
                if (target instanceof PlayerEntity &&
                        player.getScoreboardTeam() != null &&
                        player.getScoreboardTeam().equals(((PlayerEntity) target).getScoreboardTeam())) {
                    wasFalling = false;
                    critAttackScheduled = false;
                    return;
                }

                float cooldown = player.getAttackCooldownProgress(0);

                boolean onGround = player.isOnGround();
                double yVel = player.getVelocity().y;
                boolean isFalling = !onGround && yVel < -0.08;

                // Use a static cooldown threshold of 90%
                double minCooldown = 0.90;

                // --- EVENT-DRIVEN CRIT LOGIC ---
                // Detect transition from not falling to falling (descent)
                if (!wasFalling && isFalling && cooldown >= minCooldown && cooldown <= 1.0f && !critAttackScheduled) {
                    critAttackScheduled = true;
                    // Schedule the attack with a 20-50ms random delay
                    long delay = nextEventDrivenCritDelay();
                    new Thread(() -> {
                        try { Thread.sleep(delay); } catch (InterruptedException ignored) {}
                        MinecraftClient.getInstance().execute(() -> {
                            // Re-check crit state before attacking
                            ClientPlayerEntity p = MinecraftClient.getInstance().player;
                            if (p != null && client.targetedEntity != null) {
                                boolean stillOnGround = p.isOnGround();
                                double stillYVel = p.getVelocity().y;
                                boolean stillFalling = !stillOnGround && stillYVel < -0.08;
                                float stillCooldown = p.getAttackCooldownProgress(0);
                                if (stillFalling && stillCooldown >= minCooldown && stillCooldown <= 1.0f) {
                                    performAttack(client, p, client.targetedEntity);
                                    lastAttackTime = System.currentTimeMillis();
                                }
                            }
                            critAttackScheduled = false;
                        });
                    }).start();
                }
                wasFalling = isFalling;

                // --- GROUND ATTACK LOGIC ---
                // As a fallback, allow ground attacks if not falling
                if (onGround && cooldown >= minCooldown && cooldown <= 1.0f && !critAttackScheduled) {
                    long now = System.currentTimeMillis();
                    if (now - lastAttackTime >= (critPunishActive ? nextCritPunishGroundDelay() : nextGroundDelay())) {
                        performAttack(client, player, target);
                        lastAttackTime = now;
                    }
                }
            } else {
                wasFalling = false;
                critAttackScheduled = false;
            }
        });
    }

    private void performAttack(MinecraftClient client, ClientPlayerEntity player, Entity target) {
        if (client.interactionManager != null) {
            client.interactionManager.attackEntity(player, target);
            player.swingHand(Hand.MAIN_HAND);
        }
    }

    // Normal ground hit delay (returns ms)
    private long nextGroundDelay() {
        double val = 607 + random.nextGaussian() * 7;
        return clamp(val, 590, 625);
    }

    // Crit punish ground delay (returns ms)
    private long nextCritPunishGroundDelay() {
        double val = 615 + random.nextGaussian() * 7;
        return clamp(val, 605, 625);
    }

    // Event-driven crit delay: 20-50ms, gaussian randomization centered at 35ms
    private long nextEventDrivenCritDelay() {
        double val = 35 + random.nextGaussian() * 8;
        return clamp(val, 20, 50);
    }

    private long clamp(double val, int min, int max) {
        return Math.max(min, Math.min(max, Math.round(val)));
    }

    private double clampDouble(double val, double min, double max) {
        return Math.max(min, Math.min(max, val));
    }
}