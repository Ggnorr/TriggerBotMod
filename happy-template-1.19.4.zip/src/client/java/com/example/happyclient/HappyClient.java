package com.example.happyclient;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.entity.event.v1.LivingEntityDamageCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SwordItem;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.entity.damage.DamageSource;
import org.lwjgl.glfw.GLFW;

import java.util.Random;

public class HappyClient implements ClientModInitializer {
    private static final MinecraftClient client = MinecraftClient.getInstance();
    private static boolean enabled = false;
    private static KeyBinding toggleKey;
    private static boolean wasOnTarget = false;
    private static long postEatDelayUntil = 0L; // ms

    // Cooldown logic
    private static final Random RANDOM = new Random();
    private static float nextGroundCooldownThreshold = 0.0f;
    private static int groundCooldownMode = 0; // 0=90-96, 1=96-100, 2=85-92, 3=635-660ms
    private static long groundAbsoluteEarliestAttack = 0L;

    // Jump/descent logic
    private static boolean jumping = false;
    private static boolean inDescent = false;
    private static float nextAirCooldownThreshold = 0.0f;
    private static boolean lastWasDescentAttack = false;

    // Special anti-jump logic
    private static boolean specialGroundDelayActive = false;
    private static long specialGroundDelayUntil = 0L;
    private static boolean enemyDidFallingAttack = false;
    private static boolean selfDidFallingAttack = false;
    private static long lastSelfDescentAttackTime = 0L;
    private static boolean lastTargetWasJumping = false;
    private static boolean lastTargetWasOnGround = false;
    private static boolean lastTargetInDescent = false;

    // Damage listener helper
    public static class FallingAttackListener {
        public static PlayerEntity lastAttacker = null;
        public static boolean fallingAttackLanded = false;

        public static void register() {
            LivingEntityDamageCallback.EVENT.register((LivingEntity entity, DamageSource source, float amount) -> {
                if (entity instanceof PlayerEntity myPlayer) {
                    Entity attacker = source.getAttacker();
                    if (attacker instanceof PlayerEntity playerAttacker && !myPlayer.equals(playerAttacker)) {
                        // Check if attacker was falling (Y velocity < -0.01)
                        if (playerAttacker.getVelocity().y < -0.01) {
                            lastAttacker = playerAttacker;
                            fallingAttackLanded = true;
                        }
                    }
                }
                return true;
            });
        }

        public static void reset() {
            fallingAttackLanded = false;
            lastAttacker = null;
        }
    }

    @Override
    public void onInitializeClient() {
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.triggerbotlegit.toggle",
                GLFW.GLFW_KEY_LEFT_ALT,
                "category.triggerbotlegit"
        ));

        // Register the falling attack listener (damage callback)
        FallingAttackListener.register();

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            // Toggle key logic
            while (toggleKey.wasPressed()) {
                enabled = !enabled;
                if (client.player != null) {
                    client.player.sendMessage(
                            net.minecraft.text.Text.of("TriggerBot: " + (enabled ? "ON" : "OFF")), true
                    );
                }
            }

            if (!enabled || client.player == null || client.crosshairTarget == null) {
                resetState();
                return;
            }

            // Only if holding a sword
            ItemStack mainHand = client.player.getMainHandStack();
            if (!(mainHand.getItem() instanceof SwordItem)) {
                resetState();
                return;
            }

            // Only attack players
            boolean onTarget = false;
            boolean targetIsEating = false;
            boolean targetIsUsingPotion = false;
            Entity target = null;
            PlayerEntity targetPlayer = null;
            if (client.crosshairTarget.getType() == HitResult.Type.ENTITY) {
                target = ((EntityHitResult) client.crosshairTarget).getEntity();
                if (target instanceof PlayerEntity && target != client.player) {
                    onTarget = true;
                    targetPlayer = (PlayerEntity) target;
                    ItemStack targetMain = targetPlayer.getMainHandStack();
                    ItemStack targetOff = targetPlayer.getOffHandStack();
                    boolean mainEating = targetPlayer.isUsingItem() && targetPlayer.getActiveHand() == Hand.MAIN_HAND && targetMain.isFood();
                    boolean offEating = targetPlayer.isUsingItem() && targetPlayer.getActiveHand() == Hand.OFF_HAND && targetOff.isFood();
                    boolean usingPotion = targetPlayer.isUsingItem() && (targetMain.getItem().getTranslationKey().contains("potion") || targetOff.getItem().getTranslationKey().contains("potion"));
                    targetIsEating = mainEating || offEating;
                    targetIsUsingPotion = usingPotion;
                }
            }

            // Don't attack while eating from offhand or using potion
            ItemStack offhand = client.player.getStackInHand(Hand.OFF_HAND);
            boolean isEating = client.player.isUsingItem() &&
                    client.player.getActiveHand() == Hand.OFF_HAND &&
                    offhand.isFood();
            boolean isUsingPotion = client.player.isUsingItem() &&
                    (client.player.getMainHandStack().getItem().getTranslationKey().contains("potion") ||
                     client.player.getOffHandStack().getItem().getTranslationKey().contains("potion"));
            if (isEating || isUsingPotion) {
                resetState();
                return;
            }

            // Wait post-eating delay before attacking again (no delay logic anymore)
            if (System.currentTimeMillis() < postEatDelayUntil) {
                resetState();
                return;
            }

            boolean onGround = client.player.isOnGround();
            double playerVelY = client.player.getVelocity().y;

            // Target movement state
            boolean targetIsJumping = false;
            boolean targetInDescent = false;
            double targetVelY = 0.0;
            boolean targetOnGround = true;
            if (targetPlayer != null) {
                targetOnGround = targetPlayer.isOnGround();
                targetIsJumping = !targetOnGround;
                targetVelY = targetPlayer.getVelocity().y;
                targetInDescent = targetIsJumping && targetVelY < -0.01;
            }

            // If either side eating or using potion, always reset anti-jump special delay
            if (targetIsEating || targetIsUsingPotion) {
                resetAntiJumpState();
            }

            // JUMP LOGIC (unchanged, but using humanized delay)
            if (!onGround) {
                if (playerVelY > 0.01) {
                    jumping = true;
                    inDescent = false;
                    lastWasDescentAttack = false;
                    wasOnTarget = onTarget;
                    return;
                }
                if (playerVelY < -0.01) {
                    inDescent = true;
                    jumping = false;
                }
                if (inDescent && onTarget) {
                    if (nextAirCooldownThreshold == 0.0f) {
                        if (targetIsEating) {
                            nextAirCooldownThreshold = humanRandomizedCooldown(0.95f, 1.00f);
                        } else {
                            nextAirCooldownThreshold = humanRandomizedCooldown(0.85f, 0.95f);
                        }
                    }
                    float attackCooldown = client.player.getAttackCooldownProgress(0.0f);
                    if (attackCooldown >= nextAirCooldownThreshold) {
                        doAttackVanilla();
                        lastWasDescentAttack = true;
                        lastSelfDescentAttackTime = System.currentTimeMillis();
                        selfDidFallingAttack = true;
                        if (attackCooldown >= nextAirCooldownThreshold) {
                            if (targetIsEating) {
                                nextAirCooldownThreshold = humanRandomizedCooldown(0.95f, 1.00f);
                            } else {
                                nextAirCooldownThreshold = humanRandomizedCooldown(0.85f, 0.95f);
                            }
                        } else {
                            nextAirCooldownThreshold = 0.0f;
                        }
                    }
                } else {
                    lastWasDescentAttack = false;
                    nextAirCooldownThreshold = 0.0f;
                }
                wasOnTarget = onTarget;
                return;
            } else {
                jumping = false;
                inDescent = false;
                lastWasDescentAttack = false;
                nextAirCooldownThreshold = 0.0f;
            }

            // --- ANTI-JUMP LOGIC BEGIN ---
            if (onGround && onTarget && targetPlayer != null) {
                // 1. If target is jumping, I am on the ground: enable special delay, but only after he hits me from a falling attack.
                if (targetIsJumping && targetInDescent) {
                    lastTargetWasJumping = true;
                    lastTargetInDescent = true;
                }
                // True falling attack detection (from Fabric API event)
                if (FallingAttackListener.fallingAttackLanded && targetPlayer == FallingAttackListener.lastAttacker) {
                    enemyDidFallingAttack = true;
                    FallingAttackListener.reset();
                }
                if (enemyDidFallingAttack && !specialGroundDelayActive) {
                    // Enable special ground delay after enemy's falling hit
                    specialGroundDelayActive = true;
                    specialGroundDelayUntil = System.currentTimeMillis() + msFromLogNormal(595, 627);
                    enemyDidFallingAttack = false;
                }

                // 2. If I do a falling attack onto a ground enemy, and after, he uses the same trick, enable special delay for me.
                if (selfDidFallingAttack && targetOnGround && !targetIsJumping) {
                    // If target attacks after my descent, enable special delay for myself (simulate: always enable after our descent attack for now)
                    specialGroundDelayActive = true;
                    specialGroundDelayUntil = System.currentTimeMillis() + msFromLogNormal(595, 627);
                    selfDidFallingAttack = false;
                }

                // If special delay is active, use it instead of normal ground delay
                if (specialGroundDelayActive) {
                    if (System.currentTimeMillis() >= specialGroundDelayUntil) {
                        doAttackVanilla();
                        specialGroundDelayActive = false;
                        // After special delay, reset to normal ground logic for next attack
                        nextGroundCooldownThreshold = 0.0f;
                        groundCooldownMode = 0;
                        groundAbsoluteEarliestAttack = 0L;
                    }
                    // Don't do any other attacks until special delay is over
                    wasOnTarget = onTarget;
                    lastTargetWasJumping = targetIsJumping;
                    lastTargetInDescent = targetInDescent;
                    return;
                }
            } else {
                // Not on ground or not targeting player, reset anti-jump
                resetAntiJumpState();
            }
            // --- ANTI-JUMP LOGIC END ---

            // --- NORMAL GROUND LOGIC (unchanged) ---
            if (onGround && onTarget) {
                if (!wasOnTarget || (nextGroundCooldownThreshold == 0.0f && groundAbsoluteEarliestAttack == 0L)) {
                    int roll = RANDOM.nextInt(100);
                    if (roll < 70) {
                        groundCooldownMode = 0;
                        nextGroundCooldownThreshold = humanRandomizedCooldown(0.90f, 0.96f);
                        groundAbsoluteEarliestAttack = 0L;
                    } else if (roll < 80) {
                        groundCooldownMode = 1;
                        nextGroundCooldownThreshold = humanRandomizedCooldown(0.96f, 1.00f);
                        groundAbsoluteEarliestAttack = 0L;
                    } else if (roll < 90) {
                        groundCooldownMode = 2;
                        nextGroundCooldownThreshold = humanRandomizedCooldown(0.85f, 0.92f);
                        groundAbsoluteEarliestAttack = 0L;
                    } else {
                        groundCooldownMode = 3;
                        nextGroundCooldownThreshold = 0.0f;
                        groundAbsoluteEarliestAttack = System.currentTimeMillis() + (635 + RANDOM.nextInt(26));
                    }
                }

                float attackCooldown = client.player.getAttackCooldownProgress(0.0f);

                if (groundCooldownMode == 3) {
                    if (System.currentTimeMillis() >= groundAbsoluteEarliestAttack) {
                        doAttackVanilla();
                        nextGroundCooldownThreshold = 0.0f;
                        groundCooldownMode = 0;
                        groundAbsoluteEarliestAttack = 0L;
                    }
                } else {
                    if (attackCooldown >= nextGroundCooldownThreshold) {
                        doAttackVanilla();
                        int roll = RANDOM.nextInt(100);
                        if (roll < 70) {
                            groundCooldownMode = 0;
                            nextGroundCooldownThreshold = humanRandomizedCooldown(0.90f, 0.96f);
                            groundAbsoluteEarliestAttack = 0L;
                        } else if (roll < 80) {
                            groundCooldownMode = 1;
                            nextGroundCooldownThreshold = humanRandomizedCooldown(0.96f, 1.00f);
                            groundAbsoluteEarliestAttack = 0L;
                        } else if (roll < 90) {
                            groundCooldownMode = 2;
                            nextGroundCooldownThreshold = humanRandomizedCooldown(0.85f, 0.92f);
                            groundAbsoluteEarliestAttack = 0L;
                        } else {
                            groundCooldownMode = 3;
                            nextGroundCooldownThreshold = 0.0f;
                            groundAbsoluteEarliestAttack = System.currentTimeMillis() + (635 + RANDOM.nextInt(26));
                        }
                    }
                }
            } else {
                nextGroundCooldownThreshold = 0.0f;
                groundCooldownMode = 0;
                groundAbsoluteEarliestAttack = 0L;
            }

            wasOnTarget = onTarget;
            lastTargetWasJumping = targetIsJumping;
            lastTargetInDescent = targetInDescent;
            lastTargetWasOnGround = targetOnGround;
        });
    }

    private static void resetState() {
        wasOnTarget = false;
        jumping = false;
        inDescent = false;
        lastWasDescentAttack = false;
        nextGroundCooldownThreshold = 0.0f;
        groundCooldownMode = 0;
        groundAbsoluteEarliestAttack = 0L;
        resetAntiJumpState();
    }

    private static void resetAntiJumpState() {
        specialGroundDelayActive = false;
        specialGroundDelayUntil = 0L;
        enemyDidFallingAttack = false;
        selfDidFallingAttack = false;
        lastSelfDescentAttackTime = 0L;
        lastTargetWasJumping = false;
        lastTargetInDescent = false;
        lastTargetWasOnGround = false;
        FallingAttackListener.reset();
    }

    // Human-like randomized cooldown between min and max (log-normal + jitter)
    private static float humanRandomizedCooldown(float min, float max) {
        double mean = Math.log((min + max) / 2.0);
        double stddev = 0.13 + RANDOM.nextDouble() * 0.08; // more human
        float val;
        do {
            val = (float) Math.exp(mean + stddev * RANDOM.nextGaussian());
        } while (val < min || val > max);
        val += (RANDOM.nextFloat() - 0.5f) * 0.006f;
        if (val < min) val = min;
        if (val > max) val = max;
        return val;
    }

    // Human-like randomized ms delay
    private static long msFromLogNormal(int min, int max) {
        double mean = Math.log((min + max) / 2.0);
        double stddev = 0.13 + RANDOM.nextDouble() * 0.08;
        long val;
        do {
            val = (long) (Math.exp(mean + stddev * RANDOM.nextGaussian()));
        } while (val < min || val > max);
        val += (long) ((RANDOM.nextFloat() - 0.5f) * 2.0f); // jitter
        if (val < min) val = min;
        if (val > max) val = max;
        return val;
    }

    private static void doAttackVanilla() {
        if (client != null && client.player != null) {
            client.doAttack();
        }
    }
}