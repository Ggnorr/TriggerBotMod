package com.example.triggerbot;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SwordItem;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

import java.util.Random;

public class ClientModInitializer implements ClientModInitializer {
    private static KeyBinding toggleKey;
    private static boolean enabled = false;
    private static long lastAttackTime = 0;
    private static long postEatDelayUntil = 0;
    private static final Random random = new Random();

    // For ground attack timing
    private static int groundAttackCount = 0;
    private static int fastGroundAttacks = 0; // Track number of fast ground attacks (450-530ms)
    private static int nextFastGroundAttack = 13 + random.nextInt(3); // 13-15
    private static long currentAttackDelay = 0;

    // Jump (crit) attack logic
    private static boolean jumpDelayActive = false;
    private static long jumpDelayUntil = 0;
    private static boolean wasOnGroundLastTick = true;

    // FOV intersection config (degrees)
    private static final double ATTACK_FOV = 100.0; // Updated to match your in-game FOV

    @Override
    public void onInitializeClient() {
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.triggerbot.toggle",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_LEFT_ALT,
                "category.triggerbot"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (toggleKey.wasPressed()) {
                enabled = !enabled;
                if (client.player != null) {
                    client.player.sendMessage(Text.literal(enabled ? "[TriggerBot] Enabled" : "[TriggerBot] Disabled"), true);
                }
            }

            if (!enabled || client.player == null || client.world == null) return;

            // Don't attack if screen is open (chat, inventory, etc.)
            if (client.currentScreen != null) return;

            // Check if player is eating or using item in off hand
            boolean isEating = client.player.isUsingItem() || isUsingOffhand(client.player);
            if (isEating) {
                // Set post eat delay
                postEatDelayUntil = System.currentTimeMillis() + (70 + random.nextInt(21));
                return;
            }

            // Respect post-eat/use delay
            if (System.currentTimeMillis() < postEatDelayUntil) return;

            // Only attack if holding a sword in main hand
            ItemStack mainHand = client.player.getMainHandStack();
            if (!(mainHand.getItem() instanceof SwordItem)) return;

            // Find target player in crosshair
            Entity crosshairEntity = client.targetedEntity;
            if (!(crosshairEntity instanceof PlayerEntity)) return;

            PlayerEntity target = (PlayerEntity) crosshairEntity;

            // FOV intersection check
            if (!isInFov(client.player, target, ATTACK_FOV)) return;

            // Don't attack self, teammates, or dead players
            if (target == client.player || target.isDead()) return;
            if (areTeammates(client.player, target)) return;

            // Enemy state for delay logic
            boolean enemyStandingStill = target.forwardSpeed == 0 && target.sidewaysSpeed == 0;
            boolean enemyEating = target.isUsingItem();
            boolean enemySpecial = enemyStandingStill || enemyEating;

            // -- JUMP ATTACK LOGIC (CRIT) --
            boolean onGround = client.player.isOnGround();
            boolean justJumped = wasOnGroundLastTick && !onGround; // Just started a jump this tick
            wasOnGroundLastTick = onGround;

            // Activate jump delay immediately after a jump (if not already in jump delay)
            if (justJumped && !jumpDelayActive) {
                jumpDelayActive = true;
                long jumpDelay;

                // Check if enemy is eating (using item)
                if (enemyEating) {
                    int chance = random.nextInt(100);
                    if (chance < 90) {
                        jumpDelay = logRandomDelay(371, 450); // 90% 371-450ms
                    } else {
                        jumpDelay = logRandomDelay(450, 540); // 10% 450-540ms
                    }
                } else {
                    int chance = random.nextInt(100);
                    if (chance < 95) {
                        jumpDelay = logRandomDelay(320, 350); // 95% 320-350ms
                    } else if (chance < 99) {
                        jumpDelay = logRandomDelay(351, 370); // 4% 351-370ms
                    } else {
                        jumpDelay = logRandomDelay(371, 400); // 1% 371-400ms
                    }
                }
                jumpDelayUntil = System.currentTimeMillis() + jumpDelay;
            }

            // If in the air and jump delay is active, only allow attack when the jump delay has passed
            if (!onGround && jumpDelayActive) {
                if (System.currentTimeMillis() < jumpDelayUntil) return; // Wait for delay to pass
                // After delay, allow attack, reset jump delay after attack
            }

            // Reset jump delay when player lands
            if (onGround && jumpDelayActive) {
                jumpDelayActive = false;
            }

            // -- GROUND ATTACK LOGIC --
            long delay = 0;

            if (onGround && !jumpDelayActive && !enemySpecial) {
                groundAttackCount++;

                // 1 in a 13-15th ground attack is fast (450-530ms) at least twice
                if ((groundAttackCount == nextFastGroundAttack && fastGroundAttacks < 2) ||
                        (groundAttackCount % nextFastGroundAttack == 0 && fastGroundAttacks < 2)) {
                    delay = logRandomDelay(450, 530);
                    fastGroundAttacks++;
                    if (fastGroundAttacks >= 2) {
                        // Reset for next cycle
                        groundAttackCount = 0;
                        fastGroundAttacks = 0;
                        nextFastGroundAttack = 13 + random.nextInt(3); // 13-15
                    }
                } else {
                    int chance = random.nextInt(100);
                    if (chance < 95) {
                        delay = logRandomDelay(595, 627); // 95%
                    } else {
                        delay = logRandomDelay(635, 650); // 5%
                    }
                }
                currentAttackDelay = delay;
            }

            // If enemy is standing still or eating and not in jump delay, use 540-560ms
            if (enemySpecial && (!jumpDelayActive || onGround)) {
                delay = logRandomDelay(540, 560);
                currentAttackDelay = delay;
            }

            // ATTACK EXECUTION
            if (client.player.squaredDistanceTo(target) <= 6.0 && client.player.getAttackCooldownProgress(0) >= 1.0) {
                if (jumpDelayActive && !onGround) {
                    // Attack at the right jump delay window for crits
                    if (System.currentTimeMillis() - lastAttackTime > currentAttackDelay && System.currentTimeMillis() >= jumpDelayUntil) {
                        MinecraftClient.getInstance().doAttack();
                        client.player.swingHand(Hand.MAIN_HAND);
                        lastAttackTime = System.currentTimeMillis();
                        jumpDelayActive = false; // Reset after crit attack
                    }
                } else if (!jumpDelayActive && onGround) {
                    // Only attack on ground, not in air/jump state, not in jump delay
                    if (System.currentTimeMillis() - lastAttackTime > currentAttackDelay) {
                        MinecraftClient.getInstance().doAttack();
                        client.player.swingHand(Hand.MAIN_HAND);
                        lastAttackTime = System.currentTimeMillis();
                    }
                } else if (!onGround && !jumpDelayActive) {
                    // In air but not in a jump delay (e.g. fell off a block), use 540-560ms if enemySpecial
                    if (enemySpecial && System.currentTimeMillis() - lastAttackTime > currentAttackDelay) {
                        MinecraftClient.getInstance().doAttack();
                        client.player.swingHand(Hand.MAIN_HAND);
                        lastAttackTime = System.currentTimeMillis();
                    }
                }
            }
        });
    }

    private static long logRandomDelay(int min, int max) {
        // Logarithmic random delay for humanization
        double rnd = random.nextDouble();
        double logMin = Math.log(min);
        double logMax = Math.log(max);
        double logDelay = logMin + rnd * (logMax - logMin);
        return (long) Math.exp(logDelay);
    }

    private boolean areTeammates(PlayerEntity player1, PlayerEntity player2) {
        if (player1.getScoreboardTeam() != null && player2.getScoreboardTeam() != null) {
            return player1.getScoreboardTeam().isEqual(player2.getScoreboardTeam());
        }
        return false;
    }

    private boolean isUsingOffhand(PlayerEntity player) {
        if (player.isUsingItem() && player.getActiveHand() == Hand.OFF_HAND) {
            return true;
        }
        ItemStack offhand = player.getOffHandStack();
        if (offhand.getUseAction().isUsingItem()) {
            return player.isUsingItem() && player.getActiveHand() == Hand.OFF_HAND;
        }
        return false;
    }

    // FOV intersection check
    private static boolean isInFov(PlayerEntity player, Entity target, double fovDegrees) {
        Vec3d playerPos = player.getCameraPosVec(1.0f);
        Vec3d lookVec = player.getRotationVec(1.0f).normalize();
        Vec3d toTarget = target.getPos().add(0, target.getStandingEyeHeight(), 0).subtract(playerPos).normalize();

        double dot = lookVec.dotProduct(toTarget);
        double angle = Math.acos(dot) * (180.0 / Math.PI);

        return angle < (fovDegrees / 2.0);
    }
}