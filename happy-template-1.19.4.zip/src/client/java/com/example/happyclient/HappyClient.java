package com.example.happyclient;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SwordItem;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import org.lwjgl.glfw.GLFW;

import java.util.Random;

public class HappyClient implements ClientModInitializer {
    private static KeyBinding toggleKey;
    private static boolean enabled = false;
    private static long lastAttackTime = 0;
    private static long postEatDelayUntil = 0;
    private static final Random random = new Random();

    // For ground attack timing
    private static int groundAttackCount = 0;
    private static int fastGroundAttacks = 0; // Track number of fast ground attacks (450-530ms)
    private static int nextFastGroundAttack = 13 + random.nextInt(3); // 13-15
    private static long currentAttackDelay = 0;

    // Jump (crit) attack logic
    private static boolean jumpDelayActive = false;
    private static long jumpDelayUntil = 0;
    private static boolean wasOnGroundLastTick = true;

    // --- New Triggerbot Delay Logic ---
    private static long triggerbotDetectionDelayUntil = 0;
    private static Entity lastCrosshairEntity = null;

    @Override
    public void onInitializeClient() {
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.triggerbot.toggle",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_LEFT_ALT,
                "category.triggerbot"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (toggleKey.wasPressed()) {
                enabled = !enabled;
                if (client.player != null) {
                    client.player.sendMessage(Text.literal(enabled ? "[TriggerBot] Enabled" : "[TriggerBot] Disabled"), true);
                }
            }

            if (!enabled || client.player == null || client.world == null) return;

            // Don't attack if screen is open (chat, inventory, etc.)
            if (client.currentScreen != null) return;

            // Check if player is eating or using item in off hand
            boolean isEating = client.player.isUsingItem() || isUsingOffhand(client.player);
            if (isEating) {
                // Set post eat delay
                postEatDelayUntil = System.currentTimeMillis() + (70 + random.nextInt(21));
                return;
            }

            // Respect post-eat/use delay
            if (System.currentTimeMillis() < postEatDelayUntil) return;

            // Only attack if holding a sword in main hand
            ItemStack mainHand = client.player.getMainHandStack();
            if (!(mainHand.getItem() instanceof SwordItem)) return;

            // Find target player in crosshair
            Entity crosshairEntity = client.targetedEntity;
            if (!(crosshairEntity instanceof PlayerEntity)) {
                // Reset detection delay if crosshair no longer on player
                lastCrosshairEntity = null;
                triggerbotDetectionDelayUntil = 0;
                return;
            }

            PlayerEntity target = (PlayerEntity) crosshairEntity;

            // Don't attack self, teammates, or dead players
            if (target == client.player || target.isDead()) {
                lastCrosshairEntity = null;
                triggerbotDetectionDelayUntil = 0;
                return;
            }
            if (areTeammates(client.player, target)) {
                lastCrosshairEntity = null;
                triggerbotDetectionDelayUntil = 0;
                return;
            }

            // --- TRIGGERBOT REACTION DELAY LOGIC ---
            // If the crosshair just moved onto a new entity, set a new reaction delay
            if (crosshairEntity != lastCrosshairEntity) {
                triggerbotDetectionDelayUntil = System.currentTimeMillis() + getTriggerbotReactionDelay();
                lastCrosshairEntity = crosshairEntity;
            }

            // Wait for the reaction delay before allowing first attack
            if (System.currentTimeMillis() < triggerbotDetectionDelayUntil) {
                return;
            }

            // Enemy state for delay logic
            boolean enemyStandingStill = target.forwardSpeed == 0 && target.sidewaysSpeed == 0;
            boolean enemyEating = target.isUsingItem();
            boolean enemySpecial = enemyStandingStill || enemyEating;

            // -- JUMP ATTACK LOGIC (CRIT) --
            boolean onGround = client.player.isOnGround();
            boolean justJumped = wasOnGroundLastTick && !onGround; // Just started a jump this tick
            wasOnGroundLastTick = onGround;

            // Activate jump delay immediately after a jump (if not already in jump delay)
            if (justJumped && !jumpDelayActive) {
                jumpDelayActive = true;
                long jumpDelay;

                // Check if enemy is eating (using item)
                if (enemyEating) {
                    int chance = random.nextInt(100);
                    if (chance < 90) {
                        jumpDelay = logRandomDelay(371, 450); // 90% 371-450ms
                    } else {
                        jumpDelay = logRandomDelay(450, 540); // 10% 450-540ms
                    }
                } else {
                    int chance = random.nextInt(100);
                    if (chance < 95) {
                        jumpDelay = logRandomDelay(320, 350); // 95% 320-350ms
                    } else if (chance < 99) {
                        jumpDelay = logRandomDelay(351, 370); // 4% 351-370ms
                    } else {
                        jumpDelay = logRandomDelay(371, 400); // 1% 371-400ms
                    }
                }
                jumpDelayUntil = System.currentTimeMillis() + jumpDelay;
            }

            // If in the air and jump delay is active, only allow attack when the jump delay has passed
            if (!onGround && jumpDelayActive) {
                if (System.currentTimeMillis() < jumpDelayUntil) return; // Wait for delay to pass
                // After delay, allow attack, reset jump delay after attack
            }

            // Reset jump delay when player lands
            if (onGround && jumpDelayActive) {
                jumpDelayActive = false;
            }

            // -- GROUND ATTACK LOGIC --
            long delay = 0;

            if (onGround && !jumpDelayActive && !enemySpecial) {
                groundAttackCount++;

                // 1 in a 13-15th ground attack is fast (450-530ms) at least twice
                if ((groundAttackCount == nextFastGroundAttack && fastGroundAttacks < 2) ||
                        (groundAttackCount % nextFastGroundAttack == 0 && fastGroundAttacks < 2)) {
                    delay = logRandomDelay(450, 530);
                    fastGroundAttacks++;
                    if (fastGroundAttacks >= 2) {
                        // Reset for next cycle
                        groundAttackCount = 0;
                        fastGroundAttacks = 0;
                        nextFastGroundAttack = 13 + random.nextInt(3); // 13-15
                    }
                } else {
                    int chance = random.nextInt(100);
                    if (chance < 95) {
                        delay = logRandomDelay(595, 627); // 95%
                    } else {
                        delay = logRandomDelay(635, 650); // 5%
                    }
                }
                currentAttackDelay = delay;
            }

            // If enemy is standing still or eating and not in jump delay, use 540-560ms
            if (enemySpecial && (!jumpDelayActive || onGround)) {
                delay = logRandomDelay(540, 560);
                currentAttackDelay = delay;
            }

            // ATTACK EXECUTION
            if (client.player.squaredDistanceTo(target) <= 6.0 && client.player.getAttackCooldownProgress(0) >= 1.0) {
                if (jumpDelayActive && !onGround) {
                    // Attack at the right jump delay window for crits
                    if (System.currentTimeMillis() - lastAttackTime > currentAttackDelay && System.currentTimeMillis() >= jumpDelayUntil) {
                        MinecraftClient.getInstance().doAttack();
                        client.player.swingHand(Hand.MAIN_HAND);
                        lastAttackTime = System.currentTimeMillis();
                        jumpDelayActive = false; // Reset after crit attack
                    }
                } else if (!jumpDelayActive && onGround) {
                    // Only attack on ground, not in air/jump state, not in jump delay
                    if (System.currentTimeMillis() - lastAttackTime > currentAttackDelay) {
                        MinecraftClient.getInstance().doAttack();
                        client.player.swingHand(Hand.MAIN_HAND);
                        lastAttackTime = System.currentTimeMillis();
                    }
                } else if (!onGround && !jumpDelayActive) {
                    // In air but not in a jump delay (e.g. fell off a block), use 540-560ms if enemySpecial
                    if (enemySpecial && System.currentTimeMillis() - lastAttackTime > currentAttackDelay) {
                        MinecraftClient.getInstance().doAttack();
                        client.player.swingHand(Hand.MAIN_HAND);
                        lastAttackTime = System.currentTimeMillis();
                    }
                }
            }
        });
    }

    private static long logRandomDelay(int min, int max) {
        // Logarithmic random delay for humanization
        double rnd = random.nextDouble();
        double logMin = Math.log(min);
        double logMax = Math.log(max);
        double logDelay = logMin + rnd * (logMax - logMin);
        return (long) Math.exp(logDelay);
    }

    // New method for triggerbot detection delay
    private static long getTriggerbotReactionDelay() {
        int chance = random.nextInt(100);
        if (chance < 90) {
            // 90%: 55-70ms
            return logRandomDelay(55, 70);
        } else if (chance < 98) {
            // 8%: 70-100ms
            return logRandomDelay(70, 100);
        } else {
            // 2%: Attack at first tick (0ms delay)
            return 0;
        }
    }

    private boolean areTeammates(PlayerEntity player1, PlayerEntity player2) {
        if (player1.getScoreboardTeam() != null && player2.getScoreboardTeam() != null) {
            return player1.getScoreboardTeam().isEqual(player2.getScoreboardTeam());
        }
        return false;
    }

    private boolean isUsingOffhand(PlayerEntity player) {
        // Only return true if the player is using the offhand to use an item
        return player.isUsingItem() && player.getActiveHand() == Hand.OFF_HAND;
    }
}