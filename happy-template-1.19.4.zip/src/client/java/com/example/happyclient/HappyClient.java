package com.example.happyclient;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import org.lwjgl.glfw.GLFW;

import java.util.Random;

public class HappyClient implements ClientModInitializer {

    private long lastAttackTime = 0L;
    private static final Random random = new Random();

    // Crit punish tracking
    private boolean critPunishActive = false;
    private int lastHurtTime = 0;

    // Mod toggle tracking
    private boolean modEnabled = false;
    private boolean prevAltPressed = false;

    // Eating/use tracking
    private boolean wasEatingOrUsing = false;
    private long finishedEatOrUseTime = 0L;
    private boolean postEatDelayActive = false;

    // --- New: Attack scheduling/jitter ---
    private boolean attackPending = false;
    private long attackScheduledTime = 0;
    private MinecraftClient scheduledClient = null;
    private ClientPlayerEntity scheduledPlayer = null;
    private Entity scheduledTarget = null;
    // -------------------------------------

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null || client.world == null) return;
            if (client.currentScreen != null) return;

            long window = client.getWindow().getHandle();
            boolean altPressed = GLFW.glfwGetKey(window, GLFW.GLFW_KEY_LEFT_ALT) == GLFW.GLFW_PRESS;

            // Toggle mod when pressing Left Alt (on key down)
            if (altPressed && !prevAltPressed) {
                modEnabled = !modEnabled;
            }
            prevAltPressed = altPressed;

            if (!modEnabled) {
                // Reset post-eat/use tracking if mod is off
                wasEatingOrUsing = false;
                postEatDelayActive = false;
                finishedEatOrUseTime = 0L;
                // Clear pending attack if present
                attackPending = false;
                scheduledClient = null;
                scheduledPlayer = null;
                scheduledTarget = null;
                return;
            }

            ClientPlayerEntity player = client.player;

            // Don't do anything while eating or using an item in either hand
            boolean isUsing = player.isUsingItem();
            if (isUsing) {
                wasEatingOrUsing = true;
                postEatDelayActive = false;
                return;
            }

            // If just finished eating/using, start the delay
            if (wasEatingOrUsing) {
                wasEatingOrUsing = false;
                postEatDelayActive = true;
                finishedEatOrUseTime = System.currentTimeMillis();
                return; // Wait at least one tick before starting delay
            }

            // If in post-eat/use delay, wait 70-75ms before attacking
            if (postEatDelayActive) {
                long now = System.currentTimeMillis();
                // Wait a random delay between 70-75ms (uniform)
                long wait = 70 + random.nextInt(6); // 70-75 ms
                if (now - finishedEatOrUseTime < wait) {
                    return;
                } else {
                    postEatDelayActive = false; // Done waiting
                }
            }

            ItemStack main = player.getMainHandStack();
            if (!(main.getItem() == Items.WOODEN_SWORD ||
                  main.getItem() == Items.STONE_SWORD ||
                  main.getItem() == Items.IRON_SWORD ||
                  main.getItem() == Items.GOLDEN_SWORD ||
                  main.getItem() == Items.DIAMOND_SWORD ||
                  main.getItem() == Items.NETHERITE_SWORD)) {
                return;
            }

            Entity target = client.targetedEntity;
            if (target != null && target != player) {
                if (target instanceof PlayerEntity &&
                        player.getScoreboardTeam() != null &&
                        player.getScoreboardTeam().equals(((PlayerEntity) target).getScoreboardTeam())) {
                    return;
                }

                long now = System.currentTimeMillis();
                float cooldown = player.getAttackCooldownProgress(0);

                boolean onGround = player.isOnGround();
                double yVel = player.getVelocity().y;
                boolean isFalling = !onGround && yVel < -0.08;

                // Use a static cooldown threshold of 90%
                double minCooldown = 0.90;

                // Crit punish logic
                if (player.hurtTime > 0) {
                    if (player.hurtTime > lastHurtTime) {
                        critPunishActive = true;
                    }
                } else {
                    critPunishActive = false;
                }
                lastHurtTime = player.hurtTime;

                // --- Attack scheduling logic ---
                if (attackPending) {
                    // If an attack is pending, check if it's time to perform it
                    if (System.currentTimeMillis() >= attackScheduledTime) {
                        performAttack(scheduledClient, scheduledPlayer, scheduledTarget);
                        attackPending = false;
                        scheduledClient = null;
                        scheduledPlayer = null;
                        scheduledTarget = null;
                        lastAttackTime = System.currentTimeMillis();
                    }
                    // Either way, don't schedule new attacks while pending
                    return;
                }

                if (cooldown >= minCooldown && cooldown <= 1.0f) {
                    if (isFalling) {
                        long critDelay = nextNormalCritDelay();
                        if (now - lastAttackTime >= critDelay) {
                            // Schedule attack with jitter
                            scheduleAttack(client, player, target);
                        }
                    } else if (onGround) {
                        if (now - lastAttackTime >= (critPunishActive ? nextCritPunishGroundDelay() : nextGroundDelay())) {
                            // Schedule attack with jitter
                            scheduleAttack(client, player, target);
                        }
                    }
                }
                // --------------------------------
            } else {
                // If no target, clear pending attack
                attackPending = false;
                scheduledClient = null;
                scheduledPlayer = null;
                scheduledTarget = null;
            }

            // If attack was scheduled but target disappeared, clear it
            if (attackPending && (scheduledTarget == null || !scheduledTarget.isAlive())) {
                attackPending = false;
                scheduledClient = null;
                scheduledPlayer = null;
                scheduledTarget = null;
            }
        });
    }

    // Schedules an attack after a random 0-49ms jitter (lag-free)
    private void scheduleAttack(MinecraftClient client, ClientPlayerEntity player, Entity target) {
        attackScheduledTime = System.currentTimeMillis() + random.nextInt(50); // 0-49ms
        attackPending = true;
        scheduledClient = client;
        scheduledPlayer = player;
        scheduledTarget = target;
    }

    private void performAttack(MinecraftClient client, ClientPlayerEntity player, Entity target) {
        if (client.interactionManager != null) {
            // FIXED: swing first, then attack (matches vanilla order)
            player.swingHand(Hand.MAIN_HAND);
            client.interactionManager.attackEntity(player, target);
        }
    }

    // Normal ground hit delay (returns ms, uniform 590-625)
    private long nextGroundDelay() {
        // Uniform delay from 590 to 625 ms (inclusive)
        return 590 + random.nextInt(36);
    }

    // Crit punish ground delay (returns ms, uniform 605-625)
    private long nextCritPunishGroundDelay() {
        // Uniform delay from 605 to 625 ms (inclusive)
        return 605 + random.nextInt(21);
    }

    // Crit delay: uniform 310-360ms
    private long nextNormalCritDelay() {
        // Uniform delay from 310 to 360 ms (inclusive)
        return 310 + random.nextInt(51);
    }

    private long clamp(double val, int min, int max) {
        return Math.max(min, Math.min(max, Math.round(val)));
    }

    private double clampDouble(double val, double min, double max) {
        return Math.max(min, Math.min(max, val));
    }
}