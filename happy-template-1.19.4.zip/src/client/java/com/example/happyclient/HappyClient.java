package com.example.happyclient;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.entity.event.v1.DamageCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.entity.Entity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SwordItem;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import org.lwjgl.glfw.GLFW;
import java.util.Random;

public class HappyClient implements ClientModInitializer {
    private static final MinecraftClient client = MinecraftClient.getInstance();
    private static boolean enabled = false;
    private static KeyBinding toggleKey;
    private static boolean wasOnTarget = false;
    private static long postEatDelayUntil = 0L; // ms
    private static final Random RANDOM = new Random();

    // Humanized delays for ground
    private static long nextGroundAttackAllowedAt = 0L;
    private static final int GROUND_DELAY_SHORT_CHANCE = 3; // 3%
    private static final int GROUND_DELAY_SHORT_MIN = 550;
    private static final int GROUND_DELAY_SHORT_MAX = 570;
    private static final int GROUND_DELAY_LONG_MIN = 585;
    private static final int GROUND_DELAY_LONG_MAX = 600;

    private static final int POST_EAT_DELAY_MIN = 65;
    private static final int POST_EAT_DELAY_MAX = 70;

    // Jump/descent delays
    private static long nextAirAttackAllowedAt = 0L;
    private static boolean lastWasDescentAttack = false;

    // Punish Crits State
    private static boolean punishCritsActive = false;
    private static long lastCritReceivedAt = 0L;
    private static final long CRIT_PUNISH_DURATION_MS = 2000; // 2 seconds
    private static final int PUNISH_CRIT_GROUND_MIN = 600;
    private static final int PUNISH_CRIT_GROUND_MAX = 627;

    // Track last attacker for punish crits
    private static PlayerEntity lastCritAttacker = null;

    @Override
    public void onInitializeClient() {
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.triggerbotlegit.toggle",
                GLFW.GLFW_KEY_LEFT_ALT,
                "category.triggerbotlegit"
        ));

        // Listen for critical hits on the player
        DamageCallback.EVENT.register((entity, source, amount) -> {
            if (client.player != null && entity == client.player && source != null) {
                // Determine if the attacker is a player and if the hit was a crit
                Entity attacker = source.getAttacker();
                if (attacker instanceof PlayerEntity && isCrit((PlayerEntity) attacker)) {
                    punishCritsActive = true;
                    lastCritReceivedAt = System.currentTimeMillis();
                    lastCritAttacker = (PlayerEntity) attacker;
                }
            }
            return 0;
        });

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            // Toggle key logic
            while (toggleKey.wasPressed()) {
                enabled = !enabled;
                if (client.player != null) {
                    client.player.sendMessage(
                        net.minecraft.text.Text.of("TriggerBot: " + (enabled ? "ON" : "OFF")), true
                    );
                }
            }

            if (!enabled || client.player == null || client.crosshairTarget == null) {
                releaseAttackKey();
                wasOnTarget = false;
                lastWasDescentAttack = false;
                return;
            }

            // Only if holding a sword
            ItemStack mainHand = client.player.getMainHandStack();
            if (!(mainHand.getItem() instanceof SwordItem)) {
                releaseAttackKey();
                wasOnTarget = false;
                lastWasDescentAttack = false;
                return;
            }

            // Only attack players
            boolean onTarget = false;
            PlayerEntity targetPlayer = null;
            if (client.crosshairTarget.getType() == HitResult.Type.ENTITY) {
                Entity target = ((EntityHitResult) client.crosshairTarget).getEntity();
                if (target instanceof PlayerEntity && target != client.player) {
                    onTarget = true;
                    targetPlayer = (PlayerEntity) target;
                }
            }

            // Don't attack while eating from offhand
            ItemStack offhand = client.player.getStackInHand(Hand.OFF_HAND);
            boolean isEating = client.player.isUsingItem() &&
                               client.player.getActiveHand() == Hand.OFF_HAND &&
                               offhand.isFood();
            if (isEating) {
                releaseAttackKey();
                wasOnTarget = false;
                lastWasDescentAttack = false;
                // Set post-eat delay
                postEatDelayUntil = System.currentTimeMillis() + uniformDelay(POST_EAT_DELAY_MIN, POST_EAT_DELAY_MAX);
                return;
            }

            // Wait post-eating delay before attacking again
            if (System.currentTimeMillis() < postEatDelayUntil) {
                releaseAttackKey();
                wasOnTarget = false;
                lastWasDescentAttack = false;
                return;
            }

            boolean onGround = client.player.isOnGround();
            double verticalVelocity = client.player.getVelocity().y;

            long now = System.currentTimeMillis();

            // Update punish crits state (turn off after 2s with no crits from enemy)
            if (punishCritsActive && (now - lastCritReceivedAt > CRIT_PUNISH_DURATION_MS)) {
                punishCritsActive = false;
                lastCritAttacker = null;
            }

            if (onGround) {
                lastWasDescentAttack = false;

                if (verticalVelocity > 0.08) { // Some small threshold for "ascending"
                    releaseAttackKey();
                    wasOnTarget = false;
                    return;
                }

                if (onTarget && !wasOnTarget && now >= nextGroundAttackAllowedAt) {
                    // Use punish crits delay only if the target is the last crit attacker and punishCritsActive
                    if (punishCritsActive && targetPlayer != null && targetPlayer.equals(lastCritAttacker)) {
                        pressAttackKey();
                        nextGroundAttackAllowedAt = now + uniformDelay(PUNISH_CRIT_GROUND_MIN, PUNISH_CRIT_GROUND_MAX);
                    } else {
                        pressAttackKey();
                        nextGroundAttackAllowedAt = now + humanizedGroundDelay();
                    }
                } else {
                    releaseAttackKey();
                }
                wasOnTarget = onTarget;
            } else {
                // In air
                if (verticalVelocity < -0.08) { // Descent phase
                    if (onTarget && !lastWasDescentAttack) {
                        long extraDelay = 0;
                        if (targetPlayer != null && shouldApplyExtraDelay(targetPlayer)) {
                            extraDelay = uniformDelay(120, 150);
                        } else {
                            extraDelay = uniformDelay(15, 50);
                        }
                        nextAirAttackAllowedAt = now + extraDelay;
                        lastWasDescentAttack = true;
                    }
                    // Attack only after the random delay, and only once per descent
                    if (lastWasDescentAttack && now >= nextAirAttackAllowedAt && onTarget) {
                        pressAttackKey();
                    } else {
                        releaseAttackKey();
                    }
                } else {
                    lastWasDescentAttack = false;
                    releaseAttackKey();
                }
                wasOnTarget = onTarget;
            }
        });
    }

    private static void pressAttackKey() {
        client.options.attackKey.setPressed(true);
    }
    private static void releaseAttackKey() {
        client.options.attackKey.setPressed(false);
    }

    private static long uniformDelay(int min, int max) {
        return min + RANDOM.nextInt((max - min) + 1);
    }

    /**
     * 97% chance: 585-600ms,
     * 3% chance: 550-570ms
     */
    private static long humanizedGroundDelay() {
        int chance = RANDOM.nextInt(100);
        if (chance < GROUND_DELAY_SHORT_CHANCE) {
            return uniformDelay(GROUND_DELAY_SHORT_MIN, GROUND_DELAY_SHORT_MAX);
        } else {
            return uniformDelay(GROUND_DELAY_LONG_MIN, GROUND_DELAY_LONG_MAX);
        }
    }

    /**
     * Returns true if the target is looking away from the player or is eating food.
     * "Looking away" means yaw difference > 60 degrees.
     */
    private static boolean shouldApplyExtraDelay(PlayerEntity target) {
        // Check if target is eating
        ItemStack offhand = target.getStackInHand(Hand.OFF_HAND);
        boolean targetIsEating = target.isUsingItem() &&
                target.getActiveHand() == Hand.OFF_HAND &&
                offhand.isFood();

        // Compute yaw difference
        double yawDiff = Math.abs(
                wrapDegrees(
                        target.getYaw() - getYawTo(client.player, target)
                )
        );
        boolean lookingAway = yawDiff > 60;

        return targetIsEating || lookingAway;
    }

    /**
     * Returns the yaw from target to source (for accurate facing)
     */
    private static float getYawTo(PlayerEntity source, PlayerEntity target) {
        double dx = source.getX() - target.getX();
        double dz = source.getZ() - target.getZ();
        return (float) Math.toDegrees(Math.atan2(-dx, dz));
    }

    /**
     * Normalize angle to [-180, 180]
     */
    private static float wrapDegrees(double degrees) {
        degrees = degrees % 360.0;
        if (degrees >= 180.0) degrees -= 360.0;
        if (degrees < -180.0) degrees += 360.0;
        return (float) degrees;
    }

    /**
     * Simple heuristic: was the last hit a crit? (Attacker is falling and not on ground)
     * You may want to enhance this depending on what APIs are available.
     */
    private static boolean isCrit(PlayerEntity attacker) {
        return !attacker.isOnGround() && attacker.getVelocity().y < 0;
    }
}