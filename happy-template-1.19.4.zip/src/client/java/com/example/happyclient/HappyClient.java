package triggerbot.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.item.FoodComponent;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;

import java.security.SecureRandom;

public class TriggerbotClient implements ClientModInitializer {
    // Eat delay state
    private boolean postEatDelayActive = false;
    private long postEatDelayEnd = 0L;

    // Ground attack delay state
    private boolean groundDelayActive = false;
    private long groundDelayEnd = 0L;

    // Master of Crits (jump crit) delay state
    private boolean jumpDelayActive = false;
    private long jumpDelayEnd = 0L;
    private boolean critThisJump = false; // Only one crit per jump
    private boolean wasOnGround = true;   // For detecting jump events

    // Knockback descent detection state
    private boolean knockbackDescentActive = false;
    private boolean knockbackAttacked = false;
    private long knockbackGroundSuppressEnd = 0L;
    private double lastY = 0.0;

    // Reaction time state
    private Entity lastReactionTarget = null;
    private long reactionReadyTime = 0L;
    private boolean reactionFirstTick = false;

    private static final SecureRandom random = new SecureRandom();

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(this::onEndTick);
    }

    private void onEndTick(MinecraftClient client) {
        if (client == null || client.player == null || client.world == null) return;

        ClientPlayerEntity player = client.player;

        // 1. Don't attack if in GUI (inventory, chat, etc.)
        if (client.currentScreen != null) return;

        // 2. Only attack if holding a sword in main hand
        Item mainHandItem = player.getMainHandStack().getItem();
        if (!isSword(mainHandItem)) return;

        // 3. Don't attack while eating or using item (main or offhand)
        if (player.isUsingItem()) {
            postEatDelayActive = true;
            postEatDelayEnd = System.currentTimeMillis() + 70 + random.nextInt(31); // 70-100ms
            return;
        }
        if (postEatDelayActive) {
            if (System.currentTimeMillis() < postEatDelayEnd) {
                return;
            } else {
                postEatDelayActive = false;
            }
        }

        // 4. Only attack if crosshair target is a player (not self)
        if (client.crosshairTarget == null || client.crosshairTarget.getType() != HitResult.Type.ENTITY) {
            lastReactionTarget = null;
            reactionReadyTime = 0L;
            reactionFirstTick = false;
            return;
        }
        EntityHitResult entityHit = (EntityHitResult) client.crosshairTarget;
        Entity target = entityHit.getEntity();
        if (!(target instanceof PlayerEntity) || target == player) {
            lastReactionTarget = null;
            reactionReadyTime = 0L;
            reactionFirstTick = false;
            return;
        }

        // ---- FOV Intersection check (100°) ----
        if (!isInFov(player, target, 100.0)) {
            lastReactionTarget = null;
            reactionReadyTime = 0L;
            reactionFirstTick = false;
            return;
        }

        // --------- REACTION TIME LOGIC ---------
        if (target != lastReactionTarget) {
            // New target acquired
            long delay = pickReactionDelay();
            reactionReadyTime = System.currentTimeMillis() + delay;
            reactionFirstTick = true;
            lastReactionTarget = target;
        }
        // 2% chance to attack on first tick instantly
        boolean skipDelay = false;
        if (reactionFirstTick && random.nextDouble() < 0.02) {
            skipDelay = true;
        }
        if (!skipDelay && System.currentTimeMillis() < reactionReadyTime) {
            wasOnGround = player.isOnGround();
            lastY = player.getY();
            return;
        }
        reactionFirstTick = false;

        boolean onGround = player.isOnGround();
        double currY = player.getY();

        // --------- MASTER OF CRITS (JUMP) LOGIC ---------
        // If just left ground (jumped), start crit delay and reset crit state
        if (wasOnGround && !onGround) {
            critThisJump = false;
            jumpDelayActive = true;
            jumpDelayEnd = System.currentTimeMillis() + pickJumpDelay((PlayerEntity) target);
            System.out.println("[Triggerbot] Jump detected, Master of Crits delay started, ends in: " + (jumpDelayEnd - System.currentTimeMillis()) + "ms");
        }

        // --------- KNOCKBACK DESCENT LOGIC ---------
        // If airborne, not jumping, and descending (micro or otherwise)
        if (!onGround && !jumpDelayActive && (currY < lastY || player.getVelocity().y < 0)) {
            if (!knockbackDescentActive) {
                knockbackDescentActive = true;
                knockbackAttacked = false;
                // Suppress ground attacks for 800ms after this triggers
                knockbackGroundSuppressEnd = System.currentTimeMillis() + 800;
                System.out.println("[Triggerbot] Knockback descent detected! Ground suppressed until: " + knockbackGroundSuppressEnd);
            }
        }

        // If in knockback descent, attack ONCE per event, cooldown 86-100%, and suppress ground attacks
        if (knockbackDescentActive && !knockbackAttacked) {
            float cooldown = player.getAttackCooldownProgress(0);
            if (cooldown >= 0.86f && cooldown <= 1.0f) {
                client.doAttack();
                player.swingHand(Hand.MAIN_HAND);
                knockbackAttacked = true;
                // Suppress ground attacks for 800ms after this attack
                knockbackGroundSuppressEnd = System.currentTimeMillis() + 800;
                System.out.println("[Triggerbot] Knockback descent attack! Ground suppressed until: " + knockbackGroundSuppressEnd);
            }
            // Don't run ground logic during this airborne event
            wasOnGround = onGround;
            lastY = currY;
            return;
        }

        // Reset knockback descent state when landing
        if (onGround && knockbackDescentActive) {
            knockbackDescentActive = false;
            knockbackAttacked = false;
        }

        // --------- MASTER OF CRITS (JUMP) LOGIC CONTINUED ---------
        // If in air, ONLY allow crit attack after delay, ONCE per jump
        if (!onGround) {
            groundDelayActive = false; // No ground attacks during jump!

            if (jumpDelayActive) {
                if (System.currentTimeMillis() < jumpDelayEnd) {
                    wasOnGround = onGround;
                    lastY = currY;
                    return; // Wait for crit delay
                } else if (!critThisJump) {
                    // Attack cooldown check (73-100%)
                    float cooldown = player.getAttackCooldownProgress(0);
                    if (!isCooldownReady(cooldown)) {
                        wasOnGround = onGround;
                        lastY = currY;
                        return;
                    }
                    // Delay expired, perform crit attack ONCE per jump
                    jumpDelayActive = false;
                    critThisJump = true;
                    client.doAttack();
                    player.swingHand(Hand.MAIN_HAND);
                    wasOnGround = onGround;
                    lastY = currY;
                    return;
                }
            }
            wasOnGround = onGround;
            lastY = currY;
            return; // No further attacks in air
        } else {
            // If landed, reset crit state
            jumpDelayActive = false;
            critThisJump = false;
            // Now, allow normal ground hits (see below)
        }

        // --------- GROUND ATTACK LOGIC ---------
        // Don't allow ground attacks if recently suppressed by knockback descent
        if (System.currentTimeMillis() < knockbackGroundSuppressEnd) {
            wasOnGround = onGround;
            lastY = currY;
            return;
        }

        // Only applies if onGround and not in jump crit state and not suppressed
        if (!groundDelayActive) {
            long delay = pickGroundDelay();
            groundDelayEnd = System.currentTimeMillis() + delay;
            groundDelayActive = true;
            System.out.println("[Triggerbot] Ground delay: " + delay + "ms");
            wasOnGround = onGround;
            lastY = currY;
            return;
        } else {
            if (System.currentTimeMillis() < groundDelayEnd) {
                wasOnGround = onGround;
                lastY = currY;
                return; // Wait for ground delay
            } else {
                groundDelayActive = false;
            }
        }

        // Attack cooldown check (73-100%)
        float cooldown = player.getAttackCooldownProgress(0);
        if (!isCooldownReady(cooldown)) {
            wasOnGround = onGround;
            lastY = currY;
            return;
        }

        // Ready to attack on ground!
        client.doAttack();
        player.swingHand(Hand.MAIN_HAND);

        wasOnGround = onGround;
        lastY = currY;
    }

    private boolean isCooldownReady(float cooldown) {
        // Only attack if cooldown is 73% or higher (0.73-1.0)
        return cooldown >= 0.73f && cooldown <= 1.0f;
    }

    private boolean isSword(Item item) {
        return item == Items.WOODEN_SWORD ||
                item == Items.STONE_SWORD ||
                item == Items.IRON_SWORD ||
                item == Items.GOLDEN_SWORD ||
                item == Items.DIAMOND_SWORD ||
                item == Items.NETHERITE_SWORD;
    }

    /**
     * Checks if the target is within the player's FOV (centered), false otherwise.
     * fovDegrees: Full FOV angle (e.g., 100 for ±50° cone).
     */
    private boolean isInFov(ClientPlayerEntity player, Entity target, double fovDegrees) {
        // Player look vector (normalized)
        double px = player.getRotationVec(1.0f).x;
        double py = player.getRotationVec(1.0f).y;
        double pz = player.getRotationVec(1.0f).z;

        // Vector to target (normalized)
        double tx = target.getX() - player.getX();
        double ty = (target.getY() + target.getHeight() * 0.5) - (player.getY() + player.getEyeHeight(player.getPose()));
        double tz = target.getZ() - player.getZ();
        double tLen = Math.sqrt(tx*tx + ty*ty + tz*tz);
        if (tLen < 1e-6) return true; // Edge-case: same position
        tx /= tLen; ty /= tLen; tz /= tLen;

        // Dot product gives cos(angle) between vectors
        double dot = px*tx + py*ty + pz*tz;
        // Clamp dot to avoid NaN from acos due to floating point error
        dot = Math.max(-1.0, Math.min(1.0, dot));

        double angle = Math.toDegrees(Math.acos(dot)); // Angle in degrees
        return angle <= (fovDegrees / 2.0);
    }

    /**
     * Picks the reaction delay for the triggerbot, using specified probabilities and intervals.
     */
    private long pickReactionDelay() {
        double roll = random.nextDouble();
        if (roll < 0.02) {
            // 2% chance: instant attack (delay 0ms)
            return 0L;
        } else if (roll < 0.62) {
            // 60% chance: 70-90ms
            return 70 + random.nextInt(21);
        } else if (roll < 0.998) {
            // 39.8% chance: 90-100ms
            return 90 + random.nextInt(11);
        } else {
            // 0.2% chance: 150-200ms
            return 150 + random.nextInt(51);
        }
    }

    /**
     * Picks the jump delay according to your Master of Crits requirements.
     * If the enemy is eating, always returns a log-normal random in [371, 450]ms.
     */
    private long pickJumpDelay(PlayerEntity target) {
        if (target.isUsingItem() && isFood(target.getActiveItem().getItem())) {
            long delay = logNormalDelay(371, 450);
            System.out.println("[Triggerbot] Enemy eating! Using eating crit delay: " + delay + "ms");
            return delay;
        }
        double roll = random.nextDouble();
        if (roll < 0.80) {
            long delay = logNormalDelay(320, 350);
            System.out.println("[Triggerbot] Jump delay: 80% (320-350ms), rolled: " + delay + "ms");
            return delay;
        } else {
            long delay = logNormalDelay(351, 370);
            System.out.println("[Triggerbot] Jump delay: 20% (351-370ms), rolled: " + delay + "ms");
            return delay;
        }
    }

    /**
     * Your original ground delay logic with all tiers and log-normal sampling.
     */
    private long pickGroundDelay() {
        double roll = random.nextDouble();
        long delay = 0;
        if (roll < 0.70) {
            delay = logNormalDelay(590, 625);
            System.out.println("[Triggerbot] Ground delay tier: 70% (590-625ms), rolled: " + delay + "ms");
        } else if (roll < 0.80) {
            delay = logNormalDelay(560, 589);
            System.out.println("[Triggerbot] Ground delay tier: 10% (560-589ms), rolled: " + delay + "ms");
        } else if (roll < 0.88) {
            delay = logNormalDelay(627, 640);
            System.out.println("[Triggerbot] Ground delay tier: 8% (627-640ms), rolled: " + delay + "ms");
        } else if (roll < 0.90) {
            delay = logNormalDelay(660, 700);
            System.out.println("[Triggerbot] Ground delay tier: 2% (660-700ms), rolled: " + delay + "ms");
        } else if (roll < 0.998) {
            delay = logNormalDelay(540, 560);
            System.out.println("[Triggerbot] Ground delay tier: 9.8% (540-560ms), rolled: " + delay + "ms");
        } else {
            delay = logNormalDelay(450, 520);
            System.out.println("[Triggerbot] Ground delay tier: 0.2% (450-520ms), rolled: " + delay + "ms");
        }
        return delay;
    }

    /**
     * Humanizes the delay by using a log-normal distribution mapped to [min, max].
     */
    private long logNormalDelay(int min, int max) {
        double mu = 0.0;
        double sigma = 0.27; // Adjust for tighter/wider clustering
        for (int i = 0; i < 8; i++) {
            double logNormal = Math.exp(mu + sigma * random.nextGaussian());
            double normed = (logNormal - 1.0) / 2.0;
            if (normed < 0) normed = 0;
            if (normed > 1) normed = 1;
            long value = Math.round(min + (max - min) * normed);
            if (value >= min && value <= max)
                return value;
        }
        return min + random.nextInt(max - min + 1);
    }

    /**
     * Checks if an item is food.
     */
    private boolean isFood(Item item) {
        try {
            FoodComponent food = item.getFoodComponent();
            return food != null;
        } catch (Exception e) {
            return false;
        }
    }
}