package com.example.happyclient;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.entity.Entity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.scoreboard.AbstractTeam;
import net.minecraft.scoreboard.Team;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import org.lwjgl.glfw.GLFW;

import java.util.Random;

public class HappyClient implements ClientModInitializer {
    private static KeyBinding toggleKey;
    private static boolean enabled = false;
    private static boolean toggleKeyDown = false;
    private static long lastEatTime = 0;
    private static final long POST_EAT_DELAY_MS = 80;
    private static long lastAttackTime = 0;
    private static boolean attackQueued = false;
    private static long queuedAttackTime = 0;
    private static boolean jumpQueued = false;
    private static long jumpStartTime = 0;
    private static boolean wasOnGround = true;
    private static long lastAirTime = 0;
    private static final Random random = new Random();

    // Humanization: Reaction delay for normal attacks (not crit punish)
    private static long reactionQueuedTime = 0;
    private static boolean reactionQueued = false;
    private static Entity lastTarget = null;

    // FOV settings (in degrees; horizontal and vertical)
    private static final float ATTACK_FOV_HORIZONTAL_DEGREES = 75f;
    private static final float ATTACK_FOV_VERTICAL_DEGREES = 60f;

    @Override
    public void onInitializeClient() {
        toggleKey = KeyBindingHelper.registerKeyBinding(
            new KeyBinding("key.triggerbot.toggle", GLFW.GLFW_KEY_LEFT_ALT, "category.triggerbot")
        );
        ClientTickEvents.END_CLIENT_TICK.register(HappyClient::onClientTick);
    }

    private static void onClientTick(MinecraftClient mc) {
        if (mc.player == null || mc.world == null) return;

        // Toggle with left alt
        if (toggleKey.isPressed()) {
            if (!toggleKeyDown) {
                enabled = !enabled;
                mc.player.sendMessage(
                    net.minecraft.text.Text.literal("TriggerBot " + (enabled ? "Enabled" : "Disabled")),
                    true
                );
                toggleKeyDown = true;
            }
        } else {
            toggleKeyDown = false;
        }

        if (!enabled) {
            attackQueued = false;
            jumpQueued = false;
            reactionQueued = false;
            lastTarget = null;
            return;
        }

        // Don't attack if in inventory, menu, or chat
        Screen currentScreen = mc.currentScreen;
        if (currentScreen != null) return;
        if (currentScreen instanceof ChatScreen) return;

        // Don't attack if eating, using item in main hand or offhand
        if (mc.player.isUsingItem()) {
            Hand activeHand = mc.player.getActiveHand();
            ItemStack activeStack = mc.player.getActiveItem();
            if (activeHand == Hand.OFF_HAND || isFood(activeStack)) {
                if (isFood(activeStack)) {
                    lastEatTime = System.currentTimeMillis();
                }
                attackQueued = false;
                jumpQueued = false;
                reactionQueued = false;
                lastTarget = null;
                return;
            }
        }

        // Don't attack if just finished eating (delay)
        long sinceEat = System.currentTimeMillis() - lastEatTime;
        if (sinceEat < POST_EAT_DELAY_MS) {
            attackQueued = false;
            jumpQueued = false;
            reactionQueued = false;
            lastTarget = null;
            return;
        }

        // Only attack if crosshair is over a player
        if (!(mc.crosshairTarget instanceof EntityHitResult entityHitResult)) {
            attackQueued = false;
            jumpQueued = false;
            reactionQueued = false;
            lastTarget = null;
            wasOnGround = mc.player.isOnGround();
            updateLastAirTime(mc);
            return;
        }
        Entity target = entityHitResult.getEntity();
        if (!(target instanceof PlayerEntity targetPlayer)) {
            attackQueued = false;
            jumpQueued = false;
            reactionQueued = false;
            lastTarget = null;
            wasOnGround = mc.player.isOnGround();
            updateLastAirTime(mc);
            return;
        }

        // Don't attack team members
        AbstractTeam myTeam = mc.player.getScoreboardTeam();
        AbstractTeam targetTeam = targetPlayer.getScoreboardTeam();
        if (myTeam != null && targetTeam != null && myTeam.isEqual(targetTeam)) {
            attackQueued = false;
            jumpQueued = false;
            reactionQueued = false;
            lastTarget = null;
            wasOnGround = mc.player.isOnGround();
            updateLastAirTime(mc);
            return;
        }

        // Only attack if main hand is a sword
        ItemStack mainHand = mc.player.getStackInHand(Hand.MAIN_HAND);
        if (!isSword(mainHand)) {
            attackQueued = false;
            jumpQueued = false;
            reactionQueued = false;
            lastTarget = null;
            wasOnGround = mc.player.isOnGround();
            updateLastAirTime(mc);
            return;
        }

        long now = System.currentTimeMillis();

        // Track last air time for punish crits
        if (!mc.player.isOnGround()) {
            lastAirTime = now;
        }
        wasOnGround = mc.player.isOnGround();

        // ---- FOV INTERSECTION LOGIC ----
        // Only attack if intersection of horizontal and vertical FOVs
        if (!isInFovIntersection(mc, target, ATTACK_FOV_HORIZONTAL_DEGREES, ATTACK_FOV_VERTICAL_DEGREES)) {
            attackQueued = false;
            jumpQueued = false;
            reactionQueued = false;
            lastTarget = null;
            return;
        }

        // ---- CRIT PUNISH LOGIC ----
        boolean falling = mc.player.getVelocity().y < 0;
        boolean punishCritPossible = falling && canCriticalHitConditions(mc.player);

        // If punish crit is possible, attack immediately (NO reaction time!)
        if (punishCritPossible) {
            float cooldown = mc.player.getAttackCooldownProgress(0f);
            if (cooldown >= 0.90f) {
                mc.doAttack();
                lastAttackTime = now;
                attackQueued = false;
                jumpQueued = false;
                reactionQueued = false;
                lastTarget = null;
                return;
            }
        }

        // ---- JUMP CRIT LOGIC ----

        if (!mc.player.isOnGround() && !jumpQueued && !attackQueued) {
            jumpStartTime = now;
            jumpQueued = true;
        }

        if (jumpQueued) {
            // If player lands, clear queues
            if (mc.player.isOnGround()) {
                jumpQueued = false;
                attackQueued = false;
                reactionQueued = false;
                lastTarget = null;
                return;
            }

            // If enemy is eating, attack at 380-440ms after jump start (log-randomized)
            boolean targetEating = targetPlayer.isUsingItem() && isFood(targetPlayer.getActiveItem());
            long jumpElapsed = now - jumpStartTime;
            if (targetEating) {
                long delay = (long) logRandomInRange(380, 440);
                if (jumpElapsed >= delay && canCriticalHitConditions(mc.player) && mc.player.getVelocity().y < 0) {
                    mc.doAttack();
                    lastAttackTime = now;
                    jumpQueued = false;
                    attackQueued = false;
                    reactionQueued = false;
                    lastTarget = null;
                }
                return;
            }

            // 90%: attack at 310-360ms, 10%: attack at 360-370ms after jump
            if (!attackQueued) {
                double p = random.nextDouble();
                if (p < 0.9) {
                    queuedAttackTime = jumpStartTime + (long) logRandomInRange(310, 360);
                } else {
                    queuedAttackTime = jumpStartTime + (long) logRandomInRange(360, 370);
                }
                attackQueued = true;
            }
            if (now >= queuedAttackTime) {
                // Only attack if critical hit is possible (descending)
                if (canCriticalHitConditions(mc.player) && mc.player.getVelocity().y < 0) {
                    mc.doAttack();
                    lastAttackTime = now;
                    jumpQueued = false;
                    attackQueued = false;
                    reactionQueued = false;
                    lastTarget = null;
                }
            }
            return;
        }

        // ---- NORMAL GROUND DELAY LOGIC (with HUMANIZED REACTION TIME) ----
        // Only attack if not in early jump/ascent (velocity.y > 0.08)
        if (!mc.player.isOnGround() || mc.player.getVelocity().y > 0.08) {
            attackQueued = false;
            reactionQueued = false;
            lastTarget = null;
            return;
        }

        float cooldown = mc.player.getAttackCooldownProgress(0f);

        // Reaction timer logic: only (re)queue when the target changes or no reaction is pending
        if (!reactionQueued || lastTarget != target) {
            // Humanization: Queue a random reaction delay for this target
            long reactDelay = (long) logRandomInRange(36, 60); // ms, log-normal
            reactionQueuedTime = now + reactDelay;
            reactionQueued = true;
            lastTarget = target;
            // Reset attack queue for new reaction
            attackQueued = false;
        }

        // Wait for reaction time to expire
        if (now < reactionQueuedTime) {
            return;
        }

        // Now, proceed with the regular timing logic after "reaction time" has elapsed
        if (!attackQueued) {
            // 80%: 90-100% cooldown, 10%: 86-90%, 10%: 640-660ms after last attack
            double p = random.nextDouble();
            if (p < 0.8) {
                attackQueued = true;
                queuedAttackTime = now + getLogRandomDelayForCooldown(mc, 0.90f, 1.00f);
            } else if (p < 0.9) {
                attackQueued = true;
                queuedAttackTime = now + getLogRandomDelayForCooldown(mc, 0.86f, 0.90f);
            } else {
                attackQueued = true;
                queuedAttackTime = lastAttackTime + (long) logRandomInRange(640, 660);
            }
        }

        if (now < queuedAttackTime) {
            return;
        }

        // Only attack if cooldown is high enough for the selected mode
        if (attackQueued) {
            float currentCooldown = mc.player.getAttackCooldownProgress(0f);
            boolean canAttack = false;

            if (queuedAttackTime - lastAttackTime >= 640) {
                canAttack = true;
            } else if (queuedAttackTime - lastAttackTime > 0) {
                double p = random.nextDouble();
                if (p < 0.8) {
                    canAttack = currentCooldown >= 0.90f;
                } else if (p < 0.9) {
                    canAttack = currentCooldown >= 0.86f && currentCooldown < 0.90f;
                }
            }
            if (canAttack) {
                mc.doAttack();
                lastAttackTime = now;
                attackQueued = false;
                // After attack, reset reaction logic for next target reacquire
                reactionQueued = false;
                lastTarget = null;
            }
        }
    }

    /**
     * Properly sets lastAirTime when airborne.
     */
    private static void updateLastAirTime(MinecraftClient mc) {
        if (mc.player != null && !mc.player.isOnGround()) {
            lastAirTime = System.currentTimeMillis();
        }
    }

    /**
     * Returns true if the player is eligible for a critical hit except for velocity/ground timing.
     * Sprinting is allowed (toggle sprint).
     */
    private static boolean canCriticalHitConditions(PlayerEntity player) {
        return
            !player.isTouchingWater() &&
            !player.isClimbing() &&
            !player.isFallFlying() &&
            !player.hasStatusEffect(StatusEffects.BLINDNESS) &&
            !player.hasVehicle() &&
            !player.isUsingItem();
    }

    private static boolean isSword(ItemStack stack) {
        return stack != null && (
                stack.isOf(Items.WOODEN_SWORD) ||
                stack.isOf(Items.STONE_SWORD) ||
                stack.isOf(Items.IRON_SWORD) ||
                stack.isOf(Items.GOLDEN_SWORD) ||
                stack.isOf(Items.DIAMOND_SWORD) ||
                stack.isOf(Items.NETHERITE_SWORD)
        );
    }

    private static boolean isFood(ItemStack stack) {
        return stack != null && stack.getItem().getFoodComponent() != null;
    }

    // Log-random delay for cooldown (returns ms until desired cooldown reached)
    private static long getLogRandomDelayForCooldown(MinecraftClient mc, float minCooldown, float maxCooldown) {
        // Minecraft cooldown is 1.0 after 625ms for swords, so interpolate time needed
        float cooldown = mc.player.getAttackCooldownProgress(0f);
        float requiredCooldown = minCooldown + random.nextFloat() * (maxCooldown - minCooldown);
        if (cooldown >= requiredCooldown) return 0;

        float missing = requiredCooldown - cooldown;
        float timeNeeded = missing * 625f; // 625ms full cooldown for swords
        return (long) logRandomInRange((long) timeNeeded, (long) (timeNeeded + 25));
    }

    // Log-random in range [min, max)
    private static double logRandomInRange(double min, double max) {
        if (max <= min) return min;
        double logMin = Math.log(min + 1);
        double logMax = Math.log(max + 1);
        double value = Math.exp(logMin + (logMax - logMin) * random.nextDouble()) - 1;
        return value;
    }

    /**
     * Checks if the entity is within the intersection of player's horizontal and vertical FOVs.
     */
    private static boolean isInFovIntersection(MinecraftClient mc, Entity entity, float fovH, float fovV) {
        if (mc.player == null || entity == null) return false;

        // Get player pos, look, and entity pos
        double px = mc.player.getX();
        double py = mc.player.getEyeY();
        double pz = mc.player.getZ();

        double ex = entity.getX();
        double ey = entity.getEyeY();
        double ez = entity.getZ();

        // Player yaw/pitch in radians
        double yaw = Math.toRadians(mc.player.getYaw());
        double pitch = Math.toRadians(mc.player.getPitch());

        // Player look vector
        double lx = -Math.sin(yaw) * Math.cos(pitch);
        double ly = -Math.sin(pitch);
        double lz = Math.cos(yaw) * Math.cos(pitch);

        // Vector to entity
        double dx = ex - px;
        double dy = ey - py;
        double dz = ez - pz;
        double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (dist < 1e-8) return true; // overlap

        // Normalize
        dx /= dist;
        dy /= dist;
        dz /= dist;

        // Angle between look and entity (3D)
        double dot = lx * dx + ly * dy + lz * dz;
        double angle3D = Math.toDegrees(Math.acos(dot));

        // Compute horizontal and vertical angles
        // Horizontal: project both vectors onto XZ plane
        double lookLenXZ = Math.sqrt(lx * lx + lz * lz);
        double entLenXZ = Math.sqrt(dx * dx + dz * dz);
        double hDot = (lx * dx + lz * dz) / (lookLenXZ * entLenXZ);
        double angleH = Math.toDegrees(Math.acos(hDot));
        // Vertical: use pitch difference
        double lookPitch = Math.toDegrees(Math.atan2(ly, lookLenXZ));
        double entPitch = Math.toDegrees(Math.atan2(dy, entLenXZ));
        double angleV = Math.abs(lookPitch - entPitch);

        return angleH <= (fovH / 2.0) && angleV <= (fovV / 2.0);
    }
}