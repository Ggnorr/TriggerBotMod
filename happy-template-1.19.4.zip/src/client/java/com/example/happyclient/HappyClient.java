package com.example.happyclient;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import org.lwjgl.glfw.GLFW;

import java.util.Random;

public class HappyClient implements ClientModInitializer {

    private long lastAttackTime = 0L;
    private static final Random random = new Random();

    // Crit punish tracking
    private boolean critPunishActive = false;
    private int lastHurtTime = 0;

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null || client.world == null) return;
            if (client.currentScreen != null) return;

            ClientPlayerEntity player = client.player;

            // Watch for damage (approximate for crit punish)
            if (player.hurtTime > 0) {
                if (player.hurtTime > lastHurtTime) {
                    critPunishActive = true;
                }
            } else {
                critPunishActive = false;
            }
            lastHurtTime = player.hurtTime;

            long window = client.getWindow().getHandle();
            // Change from left mouse button (GLFW_MOUSE_BUTTON_1) to right mouse button (GLFW_MOUSE_BUTTON_2)
            boolean rightClickHeld = GLFW.glfwGetMouseButton(window, GLFW.GLFW_MOUSE_BUTTON_2) == GLFW.GLFW_PRESS;
            if (!rightClickHeld) return;

            ItemStack main = player.getMainHandStack();
            if (!(main.getItem() == Items.WOODEN_SWORD ||
                  main.getItem() == Items.STONE_SWORD ||
                  main.getItem() == Items.IRON_SWORD ||
                  main.getItem() == Items.GOLDEN_SWORD ||
                  main.getItem() == Items.DIAMOND_SWORD ||
                  main.getItem() == Items.NETHERITE_SWORD)) {
                return;
            }

            Entity target = client.targetedEntity;
            if (target != null && target != player) {
                if (target instanceof PlayerEntity &&
                        player.getScoreboardTeam() != null &&
                        player.getScoreboardTeam().equals(((PlayerEntity) target).getScoreboardTeam())) {
                    return;
                }

                long now = System.currentTimeMillis();
                float cooldown = player.getAttackCooldownProgress(0);

                boolean onGround = player.isOnGround();
                double yVel = player.getVelocity().y;
                boolean isFalling = !onGround && yVel < -0.08;

                // Use a static cooldown threshold of 90%
                double minCooldown = 0.90;

                if (cooldown >= minCooldown && cooldown <= 1.0f) {
                    if (isFalling) {
                        long critDelay = nextNormalCritDelay();
                        if (now - lastAttackTime >= critDelay) {
                            performAttack(client, player, target);
                            lastAttackTime = now;
                        }
                    } else if (onGround) {
                        if (now - lastAttackTime >= (critPunishActive ? nextCritPunishGroundDelay() : nextGroundDelay())) {
                            performAttack(client, player, target);
                            lastAttackTime = now;
                        }
                    }
                }
            }
        });
    }

    private void performAttack(MinecraftClient client, ClientPlayerEntity player, Entity target) {
        if (client.interactionManager != null) {
            client.interactionManager.attackEntity(player, target);
            player.swingHand(Hand.MAIN_HAND);
        }
    }

    // Normal ground hit delay (returns ms)
    private long nextGroundDelay() {
        double val = 607 + random.nextGaussian() * 7;
        return clamp(val, 590, 625);
    }

    // Crit punish ground delay (returns ms)
    private long nextCritPunishGroundDelay() {
        double val = 615 + random.nextGaussian() * 7;
        return clamp(val, 605, 625);
    }

    // Crit delay: always 310-360ms, gaussian randomization (formerly 95% window, now 100%)
    private long nextNormalCritDelay() {
        double val = 335 + random.nextGaussian() * 10; // Centered in 310-360
        val = clamp(val, 310, 360);
        return Math.round(val);
    }

    private long clamp(double val, int min, int max) {
        return Math.max(min, Math.min(max, Math.round(val)));
    }

    private double clampDouble(double val, double min, double max) {
        return Math.max(min, Math.min(max, val));
    }
}