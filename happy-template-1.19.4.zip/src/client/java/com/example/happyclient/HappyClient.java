package com.example.happyclient;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import org.lwjgl.glfw.GLFW;

import java.util.Random;

public class HappyClient implements ClientModInitializer {

    private long lastAttackTime = 0L;
    private static final Random random = new Random();

    // Crit punish tracking
    private boolean critPunishActive = false;
    private int lastHurtTime = 0;

    // Mod toggle tracking
    private boolean modEnabled = false;
    private boolean prevAltPressed = false;

    // Eating/use tracking
    private boolean wasEatingOrUsing = false;
    private long finishedEatOrUseTime = 0L;
    private boolean postEatDelayActive = false;

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null || client.world == null) return;
            if (client.currentScreen != null) return;

            long window = client.getWindow().getHandle();
            boolean altPressed = GLFW.glfwGetKey(window, GLFW.GLFW_KEY_LEFT_ALT) == GLFW.GLFW_PRESS;

            // Toggle mod when pressing Left Alt (on key down)
            if (altPressed && !prevAltPressed) {
                modEnabled = !modEnabled;
            }
            prevAltPressed = altPressed;

            if (!modEnabled) {
                // Reset post-eat/use tracking if mod is off
                wasEatingOrUsing = false;
                postEatDelayActive = false;
                finishedEatOrUseTime = 0L;
                return;
            }

            ClientPlayerEntity player = client.player;

            // Don't do anything while eating or using an item in either hand
            boolean isUsing = player.isUsingItem();
            if (isUsing) {
                wasEatingOrUsing = true;
                postEatDelayActive = false;
                return;
            }

            // If just finished eating/using, start the delay
            if (wasEatingOrUsing) {
                wasEatingOrUsing = false;
                postEatDelayActive = true;
                finishedEatOrUseTime = System.currentTimeMillis();
                return; // Wait at least one tick before starting delay
            }

            // If in post-eat/use delay, wait 65-70ms before attacking (uniform)
            if (postEatDelayActive) {
                long now = System.currentTimeMillis();
                long wait = 65 + random.nextInt(6); // 65-70 ms
                if (now - finishedEatOrUseTime < wait) {
                    return;
                } else {
                    postEatDelayActive = false; // Done waiting
                }
            }

            ItemStack main = player.getMainHandStack();
            if (!(main.getItem() == Items.WOODEN_SWORD ||
                  main.getItem() == Items.STONE_SWORD ||
                  main.getItem() == Items.IRON_SWORD ||
                  main.getItem() == Items.GOLDEN_SWORD ||
                  main.getItem() == Items.DIAMOND_SWORD ||
                  main.getItem() == Items.NETHERITE_SWORD)) {
                return;
            }

            Entity target = client.targetedEntity;
            if (target != null && target != player) {
                if (target instanceof PlayerEntity &&
                        player.getScoreboardTeam() != null &&
                        player.getScoreboardTeam().equals(((PlayerEntity) target).getScoreboardTeam())) {
                    return;
                }

                long now = System.currentTimeMillis();
                float cooldown = player.getAttackCooldownProgress(0);

                boolean onGround = player.isOnGround();
                double yVel = player.getVelocity().y;
                boolean isFalling = !onGround && yVel < -0.08;

                // Use a static cooldown threshold of 90%
                double minCooldown = 0.90;

                // Crit punish logic
                if (player.hurtTime > 0) {
                    if (player.hurtTime > lastHurtTime) {
                        critPunishActive = true;
                    }
                } else {
                    critPunishActive = false;
                }
                lastHurtTime = player.hurtTime;

                if (cooldown >= minCooldown && cooldown <= 1.0f) {
                    if (isFalling) {
                        long critDelay = nextUniformCritDelay();
                        if (now - lastAttackTime >= critDelay) {
                            performAttack(client, player, target);
                            lastAttackTime = now;
                        }
                    } else if (onGround) {
                        // --- CHANGED: Use uniform 40-65ms ground delay ---
                        if (now - lastAttackTime >= nextUniformGroundDelay()) {
                            performAttack(client, player, target);
                            lastAttackTime = now;
                        }
                    }
                }
            }
        });
    }

    private void performAttack(MinecraftClient client, ClientPlayerEntity player, Entity target) {
        if (client.interactionManager != null) {
            client.interactionManager.attackEntity(player, target);
            player.swingHand(Hand.MAIN_HAND);
        }
    }

    // Uniform ground hit delay (returns ms) -- CHANGED
    private long nextUniformGroundDelay() {
        // Uniform between 40-65ms inclusive
        return 40 + random.nextInt(26); // [40, 65] inclusive
    }

    // Uniform crit punish ground delay (returns ms) -- NOT USED in ground, but kept in case you want
    private long nextUniformCritPunishGroundDelay() {
        // Uniform between 610-640ms
        return 610 + random.nextInt(31); // [610, 640] inclusive
    }

    // Uniform crit delay: always 310-360ms
    private long nextUniformCritDelay() {
        return 310 + random.nextInt(51); // [310, 360] inclusive
    }

    private long clamp(double val, int min, int max) {
        return Math.max(min, Math.min(max, Math.round(val)));
    }

    private double clampDouble(double val, double min, double max) {
        return Math.max(min, Math.min(max, val));
    }
}