package com.example.happyclient;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.FoodComponent;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import org.lwjgl.glfw.GLFW;
import org.joml.Vector3f;

import java.util.Random;

public class HappyClient implements ClientModInitializer {
    private static final MinecraftClient mc = MinecraftClient.getInstance();
    private static boolean enabled = false;
    private static boolean wasAltPressed = false;
    private static long lastEatTime = 0;
    private static long postEatDelayMs = 0; // This will be set after each eating event
    private static long lastAttackTimeGround = 0;
    private static long lastAttackTimeAir = 0;
    private static final Random random = new Random();

    // Reaction time state
    private Entity lastTarget = null;
    private long acquiredTargetAt = 0L;
    private long reactionDelayMs = 0L;
    private boolean allowInstantReaction = false;

    // Punish crit (knockback/falling) state
    private boolean lastWasFallingPunish = false;
    private long fallingPunishStart = 0L;
    private long fallingPunishDelay = 0L;

    // Ground cooldown jitter state
    private boolean groundCooldownJitterActive = false;
    private long groundCooldownReadyAt = 0L;
    private long groundCooldownJitterMs = 0L;

    // FOV intersection settings
    private static final float ATTACK_FOV_DEGREES = 100.0f;

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> onTick());
    }

    private void resetTargetingState() {
        lastTarget = null;
        acquiredTargetAt = 0L;
        reactionDelayMs = 0L;
        allowInstantReaction = false;
        lastWasFallingPunish = false;
        fallingPunishStart = 0L;
        fallingPunishDelay = 0L;
        groundCooldownJitterActive = false;
        groundCooldownReadyAt = 0L;
        groundCooldownJitterMs = 0L;
    }

    private void onTick() {
        if (mc.player == null || mc.world == null) return;

        boolean isAltPressed = GLFW.glfwGetKey(mc.getWindow().getHandle(), GLFW.GLFW_KEY_LEFT_ALT) == GLFW.GLFW_PRESS;
        if (isAltPressed && !wasAltPressed) {
            enabled = !enabled;
        }
        wasAltPressed = isAltPressed;

        if (!enabled) return;

        ClientPlayerEntity player = mc.player;
        if (isEatingOrUsingItem(player)) return;
        if (System.currentTimeMillis() - lastEatTime < postEatDelayMs) return;
        if (!isSword(player.getMainHandStack())) return;

        Entity target = getCrosshairTarget();
        if (!(target instanceof PlayerEntity) || target == player) {
            resetTargetingState();
            return;
        }
        PlayerEntity targetPlayer = (PlayerEntity) target;
        if (isTeammate(player, targetPlayer)) {
            resetTargetingState();
            return;
        }

        // FOV intersection: only attack if the entity is within player's FOV
        if (!isInFov(player, target, ATTACK_FOV_DEGREES)) {
            resetTargetingState();
            return;
        }

        // === HUMANIZED REACTION TIME LOGIC (5% instant, 60% log-random 60-110ms, 35% log-random 120-160ms) ===
        if (lastTarget == null || !target.equals(lastTarget)) {
            // New target acquired, set reaction delay
            lastTarget = target;
            acquiredTargetAt = System.currentTimeMillis();
            float reactChance = random.nextFloat();
            if (reactChance < 0.05f) {
                // 5%: instant reaction (zero delay)
                reactionDelayMs = 0L;
                allowInstantReaction = true;
            } else if (reactChance < 0.65f) {
                // Next 60%: log-randomized delay between 60-110ms
                reactionDelayMs = 60 + (long)(-Math.log(1 - random.nextFloat()) / 1.5f * 50);
                allowInstantReaction = false;
            } else {
                // 35%: log-randomized delay between 120-160ms
                reactionDelayMs = 120 + (long)(-Math.log(1 - random.nextFloat()) / 1.5f * 40);
                allowInstantReaction = false;
            }
        }
        long now = System.currentTimeMillis();
        if (!allowInstantReaction && (now - acquiredTargetAt < reactionDelayMs)) {
            return; // Wait until reaction delay passes for this new target
        }

        // === SEPARATE KNOCKBACK CRIT LOGIC WITH EXTRA DELAY ===
        float attackCooldownProgress = player.getAttackCooldownProgress(0);
        boolean punishCritCondition = player.hurtTime > 0 &&
            player.getVelocity().y < -0.08f &&
            attackCooldownProgress >= 0.9f && attackCooldownProgress <= 1.0f;

        if (punishCritCondition) {
            if (!lastWasFallingPunish) {
                // We just started falling after knockback, set the extra delay
                fallingPunishStart = now;
                fallingPunishDelay = 50 + (long)(-Math.log(1 - random.nextFloat()) / 1.5f * 20); // log-random 50-70ms
                lastWasFallingPunish = true;
            }
            if (now - fallingPunishStart < fallingPunishDelay) {
                return; // Wait until the extra delay has passed
            }
            MinecraftClient.getInstance().doAttack();
            lastWasFallingPunish = false;
            fallingPunishStart = 0L;
            fallingPunishDelay = 0L;
            return;
        } else {
            lastWasFallingPunish = false;
            fallingPunishStart = 0L;
            fallingPunishDelay = 0L;
        }

        // === GROUND/AIR DELAY LOGIC ===
        boolean isOnGround = player.isOnGround();
        boolean isJumpingOrFalling = !isOnGround || player.getVelocity().y > 0.05 || player.fallDistance > 0.2;

        // Check enemy is eating (regardless of ground/air)
        boolean targetEating = targetPlayer.isUsingItem() && isFood(targetPlayer.getActiveItem());
        if (targetEating) {
            long delay = getLogRandomRangeMs(380, 450);
            long lastAttackTime = isJumpingOrFalling ? lastAttackTimeAir : lastAttackTimeGround;
            if (now - lastAttackTime < delay) return;
            MinecraftClient.getInstance().doAttack();
            if (isJumpingOrFalling) lastAttackTimeAir = now;
            else lastAttackTimeGround = now;
            return;
        }

        if (!isJumpingOrFalling) {
            // GROUND DELAY LOGIC
            float cooldown = getCooldownForAttackGround();
            attackCooldownProgress = player.getAttackCooldownProgress(0);

            if (now - lastAttackTimeGround < 5) return; // Prevent attacking multiple times per tick

            boolean useCooldownThreshold = false;
            float cooldownThreshold = 0.9f;

            if (cooldown >= 0.99f) {
                // 90-100% cooldown (70%)
                if (attackCooldownProgress < 0.9f) {
                    groundCooldownJitterActive = false;
                    return;
                }
                useCooldownThreshold = true;
                cooldownThreshold = 0.9f;
            } else if (cooldown >= 0.84f && cooldown <= 0.89f) {
                // 84-89% cooldown (10%)
                if (attackCooldownProgress < cooldown) {
                    groundCooldownJitterActive = false;
                    return;
                }
                useCooldownThreshold = true;
                cooldownThreshold = cooldown;
            }

            if (useCooldownThreshold) {
                if (!groundCooldownJitterActive) {
                    groundCooldownReadyAt = now;
                    groundCooldownJitterMs = getLogRandomRangeMs(15, 50); // 15–50ms jitter
                    groundCooldownJitterActive = true;
                    return;
                }
                if (now - groundCooldownReadyAt < groundCooldownJitterMs) {
                    return;
                }
                groundCooldownJitterActive = false;
            } else if (cooldown == -2f) {
                // 2%: 660-700ms delay (log-randomized)
                groundCooldownJitterActive = false;
                long delay = getLogRandomRangeMs(660, 700);
                if (now - lastAttackTimeGround < delay) return;
            } else {
                // 8%: 625-640ms delay
                groundCooldownJitterActive = false;
                long delay = getLogRandomRangeMs(625, 640);
                if (now - lastAttackTimeGround < delay) return;
            }

            MinecraftClient.getInstance().doAttack();
            lastAttackTimeGround = now;
        } else {
            // JUMP DELAY LOGIC
            groundCooldownJitterActive = false;
            long delay = getJumpDelayMs();
            if (now - lastAttackTimeAir < delay) return;
            MinecraftClient.getInstance().doAttack();
            lastAttackTimeAir = now;
        }
    }

    private boolean isInFov(ClientPlayerEntity player, Entity target, float fovDegrees) {
        float pitch = player.getPitch();
        float yaw = player.getYaw();
        Vector3f lookVec = getLookVector(pitch, yaw);

        double dx = target.getX() - player.getX();
        double dy = (target.getY() + target.getHeight() / 2.0) - (player.getY() + player.getEyeHeight(player.getPose()));
        double dz = target.getZ() - player.getZ();
        Vector3f toTarget = new Vector3f((float) dx, (float) dy, (float) dz);
        toTarget.normalize();

        float dot = lookVec.dot(toTarget);
        float angle = (float) Math.acos(dot) * (180.0f / (float) Math.PI);

        return angle <= (fovDegrees / 2.0f);
    }

    private Vector3f getLookVector(float pitch, float yaw) {
        float radYaw = (float) Math.toRadians(-yaw - 180.0f);
        float radPitch = (float) Math.toRadians(-pitch);
        float x = (float) (Math.sin(radYaw) * Math.cos(radPitch));
        float y = (float) Math.sin(radPitch);
        float z = (float) (Math.cos(radYaw) * Math.cos(radPitch));
        Vector3f result = new Vector3f(x, y, z);
        result.normalize();
        return result;
    }

    // 70%: 0.90-1.00 cooldown
    // 10%: 0.84-0.89 cooldown
    // 8%: 625-640ms delay
    // 2%: 660-700ms delay (log-randomized)
    private float getCooldownForAttackGround() {
        float p = random.nextFloat();
        if (p < 0.7f) {
            return 0.9f + (logRandom() * 0.1f); // [0.9, 1.0]
        } else if (p < 0.8f) {
            return 0.84f + (logRandom() * 0.05f); // [0.84, 0.89]
        } else if (p < 0.98f) {
            return -1f; // 8%
        } else {
            return -2f; // 2%
        }
    }

    private long getJumpDelayMs() {
        float p = random.nextFloat();
        if (p < 0.9f) {
            return getLogRandomRangeMs(330, 360); // 90%
        } else {
            return getLogRandomRangeMs(365, 380); // 10%
        }
    }

    private float logRandom() {
        return (float) (-Math.log(1 - random.nextFloat())) / 1.5f;
    }

    private long getLogRandomRangeMs(int min, int max) {
        float r = logRandom();
        return min + (long) (r * (max - min));
    }

    private boolean isSword(ItemStack stack) {
        return stack.getItem() == Items.WOODEN_SWORD ||
                stack.getItem() == Items.STONE_SWORD ||
                stack.getItem() == Items.IRON_SWORD ||
                stack.getItem() == Items.GOLDEN_SWORD ||
                stack.getItem() == Items.DIAMOND_SWORD ||
                stack.getItem() == Items.NETHERITE_SWORD;
    }

    private boolean isEatingOrUsingItem(ClientPlayerEntity player) {
        ItemStack main = player.getMainHandStack();
        ItemStack off = player.getOffHandStack();
        boolean eating = player.isUsingItem() && (isFood(main) || isFood(off));
        boolean using = player.isUsingItem() && !eating;
        if (!player.isUsingItem() && player.getItemUseTime() > 0 && (isFood(main) || isFood(off))) {
            lastEatTime = System.currentTimeMillis();
            postEatDelayMs = 75 + (long)(Math.random() * 6); // recalculate every time eating ends
        }
        return eating || using;
    }

    private boolean isFood(ItemStack stack) {
        FoodComponent food = stack.getItem().getFoodComponent();
        return food != null;
    }

    private Entity getCrosshairTarget() {
        if (mc.crosshairTarget instanceof EntityHitResult entityHit && mc.crosshairTarget.getType() == HitResult.Type.ENTITY) {
            return entityHit.getEntity();
        }
        return null;
    }

    private boolean isTeammate(PlayerEntity player, PlayerEntity target) {
        return player.isTeammate(target);
    }
}