import java.io.*;
import java.nio.file.*;
import java.util.jar.*;
import java.util.zip.*;

public class SodiumGL4ESPatcher {

    private static final String[] BLOCKED_CLASSES = {
            "me/jellysquid/mods/sodium/client/render/chunk/terrain/TerrainRenderPipeline.class",
            "me/jellysquid/mods/sodium/client/render/chunk/terrain/passes/IndirectDrawManager.class",
            "me/jellysquid/mods/sodium/client/render/chunk/vertex/format/CompactVertexEncoder.class"
    };

    private static final String[] SHADER_KEYWORDS = {
            "ARB_buffer_storage", "glDrawArraysIndirect", "GL43", "GL32", "shaderException"
    };

    public static void main(String[] args) throws Exception {
        Path inputDir = Paths.get("mods_unpatched");
        Path outputDir = Paths.get("mods_patched");

        Files.createDirectories(inputDir);
        Files.createDirectories(outputDir);

        Files.list(inputDir)
            .filter(p -> p.toString().endsWith(".jar"))
            .forEach(jarPath -> {
                try {
                    System.out.println("[*] Patching: " + jarPath.getFileName());

                    Path tempDir = Files.createTempDirectory("patch_");
                    unzipJar(jarPath, tempDir);
                    patchClasses(tempDir);
                    Path outputJar = outputDir.resolve(jarPath.getFileName());
                    zipDir(tempDir, outputJar);

                    deleteDirectory(tempDir.toFile());

                    System.out.println("[✓] Patched: " + outputJar.getFileName());
                } catch (Exception e) {
                    System.err.println("[!] Failed to patch: " + jarPath.getFileName());
                    e.printStackTrace();
                }
            });

        System.out.println("Done patching all .jar files.");
    }

    private static void unzipJar(Path jarFile, Path destDir) throws IOException {
        try (JarInputStream jis = new JarInputStream(Files.newInputStream(jarFile))) {
            JarEntry entry;
            while ((entry = jis.getNextJarEntry()) != null) {
                Path filePath = destDir.resolve(entry.getName());
                if (entry.isDirectory()) continue;
                Files.createDirectories(filePath.getParent());
                Files.copy(jis, filePath, StandardCopyOption.REPLACE_EXISTING);
            }
        }
    }

    private static void patchClasses(Path baseDir) throws IOException {
        Files.walk(baseDir)
            .filter(p -> p.toString().endsWith(".class"))
            .forEach(path -> {
                String relPath = baseDir.relativize(path).toString().replace("\\", "/");

                // Delete blocked classes
                for (String blocked : BLOCKED_CLASSES) {
                    if (relPath.equals(blocked)) {
                        try {
                            Files.deleteIfExists(path);
                            System.out.println("[-] Removed incompatible class: " + blocked);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        return;
                    }
                }

                // Remove classes containing problematic OpenGL strings
                try {
                    byte[] data = Files.readAllBytes(path);
                    String content = new String(data);
                    for (String keyword : SHADER_KEYWORDS) {
                        if (content.contains(keyword)) {
                            Files.delete(path);
                            System.out.println("[-] Removed class with keyword: " + keyword + " -> " + relPath);
                            return;
                        }
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            });

        // Also remove shader-related files
        Files.walk(baseDir)
            .filter(p -> p.toString().endsWith(".glsl") || p.toString().contains("shader"))
            .forEach(path -> {
                try {
                    Files.deleteIfExists(path);
                    System.out.println("[-] Removed shader resource: " + baseDir.relativize(path));
                } catch (IOException e) {
                    e.printStackTrace();
                }
            });
    }

    private static void zipDir(Path sourceDir, Path jarFile) throws IOException {
        try (JarOutputStream jos = new JarOutputStream(Files.newOutputStream(jarFile))) {
            Files.walk(sourceDir)
                .filter(path -> !Files.isDirectory(path))
                .forEach(path -> {
                    try {
                        String entryName = sourceDir.relativize(path).toString().replace("\\", "/");
                        JarEntry entry = new JarEntry(entryName);
                        jos.putNextEntry(entry);
                        Files.copy(path, jos);
                        jos.closeEntry();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                });
        }
    }

    private static void deleteDirectory(File directory) {
        File[] allContents = directory.listFiles();
        if (allContents != null) {
            for (File file : allContents) {
                deleteDirectory(file);
            }
        }
        directory.delete();
    }
}